import { Box } from "@mui/material";
import { Link } from "react-router";

const Unauthorized = () => {
    return (
        <Box className="h-screen">
            <Box className="grid min-h-full place-items-center bg-white px-6 py-24 sm:py-32 lg:px-8">
                <Box className="text-center">
                    <p className="font-semibold text-indigo-600 text-4xl">401</p>
                    <h1 className="mt-4 text-5xl font-semibold tracking-tight text-balance text-gray-900 sm:text-7xl">Akses Tidak Sah</h1>
                    <p className="mt-6 text-lg font-medium text-pretty text-gray-500 sm:text-xl/8">Akses telah dibatasi karena akses tidak sah, silakan untuk login untuk mendapatkan akses.</p>
                    <Box className="mt-10 flex items-center justify-center gap-x-6">
                        <Link to="/" className="rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-xs hover:bg-indigo-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                            Kembali Login
                        </Link>
                    </Box>
                </Box>
            </Box>
        </Box>
    );
}

export default Unauthorized;