import { Box, Button, Card, CircularProgress, Drawer, InputAdornment, Modal, TextField, Typography } from "@mui/material"
import { useEffect, useState } from 'react'
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined'
import KeyboardDoubleArrowRightOutlinedIcon from '@mui/icons-material/KeyboardDoubleArrowRightOutlined'
import DataTable from "../../components/table"
import { addCategory, deleteCategory, getCategory, updateCategory } from "../../request/category"
import Alerts from "../../components/alert"
import { DELEY_TIME } from "../../utils/config"

const initialForm = {
    category: "",
    description: ""
}

const Category = () => {
    const [data, setData] = useState([])
    const [keyword, setKeyword] = useState('')
    const [drawer, setDrawer] = useState(false)
    const [modal, setModal] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [loading, setLoading] = useState(false)
    const [deleteId, setDeleteId] = useState([])
    const [msg, setMsg] = useState('')


    const columns = [
        { label: "Name", key: "category" },
        { label: "Keterangan", key: "description" },
    ]

    const getData = async () => {
        const category = await getCategory()
        setData(category.data)
    }

    const dataSelected = (ids) => {
        ids.length > 0 ? setDeleteId(ids) : setDeleteId([])
    }

    const research = (e) => {
        setKeyword(e.target.value)
    }

    const formCategory = async (e) => {
        e.preventDefault()
        setLoading(!loading)

        const { status, message } = await (form.id ? updateCategory(form) : addCategory(form))

        if (status == 'success') {
            getData()
            drawerClose()
            setLoading(!loading)
        } else {
            setMsg(message)
            drawerClose()
            setLoading(!loading)
        }
    }

    const setInputCategory = (e) => {
        e.preventDefault()
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    const editData = (id) => {
        let forms = data.find((item) => item.id == id)
        setLoading(false)
        setForm(forms)
        drawerOpen()
    }

    const deleteData = async () => {
        const promises = deleteId.map(async (item) => {
            const { status, message } = await deleteCategory(item)
            return status != 'success' && message
        })

        const messages = await Promise.all(promises)
        messages.filter(item => item).length > 0 && setMsg(messages.join(', '))

        getData()
        setDeleteId([])
        confirmDelete()
    }

    const confirmDelete = () => {
        setModal(!modal)
    }

    const drawerOpen = () => {
        loading && setLoading(false)
        setDrawer(true)
    }

    const drawerClose = () => {
        !loading && setDrawer(false)
        setForm(initialForm)
    }

    useEffect(() => {
        getData()
    }, [])

    useEffect(() => {
        setTimeout(() => {
            setMsg('')
        }, DELEY_TIME)
    }, [msg])

    return (
        <>
            <header className='mb-10'>
                <Typography variant="h4" component="h4" sx={{ mb: 1 }}>Jenis Akta</Typography>
                <Typography variant="p" component="p">Jenis Akta akan digunakan sebagai kategori dari surat yang akan di tambahkan</Typography>
            </header>

            <Alerts status={'error'}>{msg}</Alerts>

            <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="pt-4" elevation={0} >
                <Box className="flex items-center justify-between mb-4 px-4">
                    <TextField type="email" variant="outlined" onChange={research} placeholder="Cari jenis akta" slotProps={{
                        input: {
                            startAdornment: (
                                <InputAdornment position="start">
                                    <SearchOutlinedIcon />
                                </InputAdornment>
                            ),
                        },
                    }} />

                    {deleteId.length > 0 ? <Button type="button" variant="contained" color="error" sx={{ my: '15px', bgcolor: 'var(--color-maroon-1)' }} onClick={confirmDelete}>
                        Hapus Data
                    </Button> : <Button type="button" variant="contained" color="primary" sx={{ my: '15px' }} onClick={drawerOpen} >
                        Tambah Jenis Surat
                    </Button>}
                </Box>
                <DataTable datas={{ columns, data }} selectable={{ target: 'id', onSelect: dataSelected }} search={keyword} action={{
                    edit: { icon: <KeyboardDoubleArrowRightOutlinedIcon />, label: 'Ubah', onClick: editData, callBack: 'id' }
                }} />
            </Card>

            <Drawer anchor="right" open={drawer} onClose={drawerClose} elevation={0} >
                <Box className="px-8 py-10 w-md">
                    <Typography variant='h5' component='h5' sx={{ mb: 4 }}>{form.id ? 'Ubah Jenis Surat' : 'Tambah Jenis Surat'}</Typography>
                    <form onSubmit={formCategory}>
                        <Box className="flex flex-col gap-2 mb-6">
                            <label component='label' htmlFor="category" >Jenis Baru</label>
                            <TextField id="category" name="category" type="text" fullWidth variant="outlined" value={form.category} onChange={setInputCategory} />
                        </Box>
                        <Box className="flex flex-col gap-2 mb-6">
                            <label component='label' htmlFor="description" >Keterangan</label>
                            <TextField id="description" name="description" type="text" fullWidth variant="outlined" multiline rows={8} value={form.description} onChange={setInputCategory} />
                        </Box>
                        <Box className="flex justify-end gap-2 mb-6">
                            <Button type="submit" variant="contained" color="primary" loadingPosition="center" loadingIndicator={<CircularProgress color="primary" size={20} />} loading={loading}>
                                {form.id ? 'Simpan perubahan' : 'Tambah Jenis'}
                            </Button>
                        </Box>
                    </form>
                </Box>
            </Drawer>

            <Modal open={modal} onClose={confirmDelete} >
                <Box className="flex items-center justify-center h-screen">
                    <Box className="w-xl p-6 bg-white rounded-lg shadow-md">
                        <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                            Konfirmasi Hapus Data
                        </Typography>
                        <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>
                            Yakin&nbsp;
                            {data.filter(item => deleteId.includes(item.id)).map(item => <Typography variant="span" component="span" align="center" fontWeight="bold" color="var(--color-black-3)" key={item.id}> {item.category}<Typography variant="span" component="span" fontWeight={'normal'}>,</Typography> </Typography>)}
                            &nbsp;akan di hapus, data yang telah dihapus tidak dapat dipulihkan kembali, pastikan anda yakin untuk menghapusnya
                        </Typography>
                        <Box className="w-full flex justify-end">
                            <Button variant="text" color="primary" onClick={confirmDelete}>Batalkan</Button>
                            <Button variant="text" color="error" onClick={deleteData}>Hapus</Button>
                        </Box>
                    </Box>
                </Box>
            </Modal>
        </>
    )
}

export default Category