import { Avatar, Box, List, ListItemButton, ListItemIcon, ListItemText, MenuItem, Typography } from "@mui/material"
import { useEffect, useState } from "react"
import { Link, useLocation, useNavigate } from "react-router"
import Router from "./router"
import MenuRoundedIcon from '@mui/icons-material/MenuRounded'
import CottageOutlinedIcon from '@mui/icons-material/CottageOutlined'
import AccountTreeOutlinedIcon from '@mui/icons-material/AccountTreeOutlined'
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined'
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined'
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined'
import LockOutlinedIcon from '@mui/icons-material/LockOutlined'
import { deleteToken } from "../../utils/functions"
import Dropdown from "../../components/drobdown"
import { STATIC_ASSETS } from "../../utils/config"

const Layout = () => {
    const [open, setOpen] = useState(true)
    const { pathname } = useLocation()
    const navigate = useNavigate()
    const avatar = localStorage.getItem('avatar')

    const toggleMenu = () => {
        setOpen(!open)
    }

    const logout = () => {
        deleteToken()
        navigate('/')
    }

    const sideCondition = () => {
        if (window.innerWidth < 1024) {
            setOpen(false)
        } else {
            setOpen(true)
        }
    }

    useEffect(() => {
        sideCondition()
        window.addEventListener('resize', sideCondition)
        return () => window.removeEventListener('resize', sideCondition)
    }, [])

    return (
        <Box className="flex h-screen">
            <Box className="w-full relative">
                <Box className={`${open ? 'w-[280px]' : 'w-[84px]'} flex h-screen flex-col justify-between border-e border-gray-100 fixed z-50 bg-white transition-all`}>
                    <Box className="p-4">
                        <Box className="flex items-center justify-between mb-10">
                            <Box className="flex items-center">
                                <svg className="min-w-[45px] max-w-[45px]" viewBox="0 0 45 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M28.5714 16.4286L17.1077 5C17.1077 5 9.72834 11.9654 4.99998 16.4286" stroke="#6F64F8" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
                                    <path d="M40 23.5714L28.5363 35C28.5363 35 21.1569 28.0346 16.4286 23.5714" stroke="#6F64F8" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                                {open && <Typography variant="h5" component="h5" fontWeight={600} noWrap sx={{ ml: 2 }} >Arsip App</Typography>}
                            </Box>

                            <button onClick={toggleMenu} className="translate-x-16">
                                <MenuRoundedIcon color="primary" fontSize="large" />
                            </button>
                        </Box>

                        <List component="nav">
                            <ListItemButton component={Link} to={'/archive'} selected={pathname == '/archive'} sx={{ mb: '8px' }} onClick={sideCondition}>
                                <ListItemIcon sx={{ minWidth: 0, pr: '15px' }}>
                                    <CottageOutlinedIcon fontSize='medium' />
                                </ListItemIcon>
                                {open &&
                                    <ListItemText>
                                        <Typography fontWeight={600} variant="span" component='span' color="inherit" noWrap>Beranda</Typography>
                                    </ListItemText>
                                }
                            </ListItemButton>
                            <ListItemButton component={Link} to={'/archive/category'} selected={pathname.includes('/category')} sx={{ mb: '8px' }} onClick={sideCondition}>
                                <ListItemIcon sx={{ minWidth: 0, pr: '15px' }}>
                                    <AccountTreeOutlinedIcon fontSize='medium' />
                                </ListItemIcon>
                                {open &&
                                    <ListItemText>
                                        <Typography fontWeight={600} variant="span" component='span' color="inherit" noWrap>Jenis Akta</Typography>
                                    </ListItemText>
                                }
                            </ListItemButton>
                            <ListItemButton component={Link} to={'/archive/manage'} selected={pathname.includes('/manage')} sx={{ mb: '8px' }} onClick={sideCondition}>
                                <ListItemIcon sx={{ minWidth: 0, pr: '15px' }}>
                                    <Inventory2OutlinedIcon fontSize='medium' />
                                </ListItemIcon>
                                {open &&
                                    <ListItemText>
                                        <Typography fontWeight={600} variant="span" component='span' color="inherit" noWrap>Arsip Akta</Typography>
                                    </ListItemText>
                                }
                            </ListItemButton>
                            <ListItemButton component={Link} to={'/archive/receiver'} selected={pathname.includes('/receiver')} sx={{ mb: '8px' }} onClick={sideCondition}>
                                <ListItemIcon sx={{ minWidth: 0, pr: '15px' }}>
                                    <PeopleAltOutlinedIcon fontSize='medium' />
                                </ListItemIcon>
                                {open &&
                                    <ListItemText>
                                        <Typography fontWeight={600} variant="span" component='span' color="inherit" noWrap>Kelola Penerima</Typography>
                                    </ListItemText>
                                }
                            </ListItemButton>
                            <ListItemButton component={Link} to={'/archive/users'} selected={pathname.includes('/users')} sx={{ mb: '8px' }} onClick={sideCondition}>
                                <ListItemIcon sx={{ minWidth: 0, pr: '15px' }}>
                                    <AdminPanelSettingsOutlinedIcon fontSize='medium' />
                                </ListItemIcon>
                                {open &&
                                    <ListItemText>
                                        <Typography fontWeight={600} variant="span" component='span' color="inherit" noWrap>Kelola Pengguna</Typography>
                                    </ListItemText>
                                }
                            </ListItemButton>
                        </List>
                    </Box>
                </Box>

                <Box className={`${open ? 'w-[calc(100vw-84px)] lg:w-[calc(100vw-280px)]' : 'w-[calc(100vw-84px)]'} absolute right-0`}>
                    <Box className="flex items-center justify-end sticky w-full top-0 right-0 px-4 py-4 z-10 header-background">
                        <Dropdown trigger={avatar ?
                            <Avatar alt="Avatar" src={[STATIC_ASSETS, 'avatar/', avatar].join('')} />
                            :
                            <Avatar alt="Avatar" src="/img/avatar.png" />
                        } >
                            <MenuItem onClick={logout}>
                                <ListItemIcon>
                                    <LockOutlinedIcon fontSize="small" />
                                </ListItemIcon>
                                Logout
                            </MenuItem>
                        </Dropdown>
                    </Box>

                    <Box className="p-[20px] relative">
                        <Router />
                    </Box>
                </Box>
            </Box>

        </Box>

    )
}

export default Layout