import { Box, Typography, Avatar, Button, TextField, Modal, Card, Chip } from "@mui/material"
import { useEffect, useState } from "react"
import { user } from "../../request/dummy"
import FormUser from "./form-user";
import EditNoteOutlinedIcon from '@mui/icons-material/EditNoteOutlined';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined';
import { deleteUser, getUser, uploadAvatarUser } from "../../request/user";
import Alerts from "../../components/alert";
import { decrypt } from "../../utils/encryp";

const initialForm = {
    name: "",
    email: "",
    password: '',
    avatar: "",
    phone: '',
    province: '',
    city: '',
    subdistrict: '',
    ward: '',
    status: false
}

const initialFormData = {
    id: ''
}

const Users = () => {
    const [openDeleteModal, setOpenDeleteModal] = useState(false)
    const [data, setData] = useState([])
    const [users, setUsers] = useState([])
    const [deleteId, setDeleteId] = useState(null)
    const [openForm, setOpenForm] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [formData, setFormData] = useState(initialFormData)
    const [modalUploadFile, setModalUploadFile] = useState(false)
    const [msg, setMsg] = useState('')

    const search = (e) => {
        const { value } = e.target
        setUsers(value ? user.filter(item => item.name.toLowerCase().includes(value.toLowerCase())).slice(0, 10) : user.slice(0, 10))
    }

    const getData = async () => {
        const receiver = await getUser()
        setData(receiver.data)
    }

    const DeleteModal = () => {
        setOpenDeleteModal(!openDeleteModal)
        deleteId && setDeleteId(null)
    }

    const ConfirmDelete = (e) => {
        setDeleteId(...users.filter(item => e.target.dataset.id.includes(item.id)))
        DeleteModal()
    }

    const deleteData = async () => {
        await deleteUser(deleteId.id)
        getData()
        DeleteModal()
    }

    const toggleFormUser = () => {
        setOpenForm(!openForm)
    }

    const formClose = () => {
        toggleFormUser()
        setForm(initialForm)
        getData()
    }

    const editData = (e) => {
        let forms = users.find((item) => item.id == e.target.dataset.id)
        setForm(forms)
        toggleFormUser()
    }

    const uploadFile = (e) => {
        setFormData({ ...formData, id: e.target.dataset.id })
        setModalUploadFile(!modalUploadFile)
    }

    const handleFile = (e) => {
        e.preventDefault()
        const file = e.target.files[0]
        const allowType = ['png', 'jpg', 'jpeg']
        const fileType = file.type.split('/').pop()

        if (file) {
            allowType.includes(fileType) ? setFormData({ ...formData, avatar: file }) : (() => {
                setMsg('file tidak sesuai')
            })()
        }
    }

    useEffect(() => {
        setUsers(data.slice(0, 10))
    }, [data])

    useEffect(() => {
        if (formData.avatar) {
            uploadAvatarUser(formData).then(({ data }) => {
                getData()
                setFormData(initialFormData)
                setModalUploadFile(!modalUploadFile)

                if (data) {
                    const { avatar } = JSON.parse(decrypt(data))
                    localStorage.setItem('avatar', avatar)
                }
            })
        }
    }, [formData])

    useEffect(() => {
        getData()
    }, [])

    return (
        openForm ? <FormUser form={form} onClose={formClose} /> : <>
            <Alerts status={'error'}>{msg}</Alerts>
            <Box className="flex flex-col max-w-5xl gap-4 mx-auto relative">
                <Box className="flex justify-between items-center gap-4 sticky top-[68px] z-10 bg-[var(--color-grey-1)] py-4 ">
                    <TextField id="number" name="number" type="text" fullWidth variant="outlined" label="Cari nama pengguna" onChange={search} />
                    <Button type="button" variant="contained" color="primary" size="small" sx={{ py: '16.5px', px: 4, textWrap: 'nowrap' }} onClick={toggleFormUser}>Buat Pengguna</Button>
                </Box>
                {users.map((item) =>
                    <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="relative flex gap-8 py-4 px-8" key={item.id} >
                        <Avatar src={item.avatar} sx={{
                            position: 'relative', width: '150px', height: '150px', borderRadius: 1, cursor: 'pointer',
                            '&::before': {
                                content: '""',
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                width: '100%',
                                height: '100%',
                                transition: 'all ease-in-out 0.3s'
                            },
                            '&::after': {
                                content: `'Ubah'`,
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                width: 'fit-content',
                                height: 'fit-content',
                                padding: '10px 18px',
                                transition: 'all ease-in-out 0.3s',
                                transform: 'translate(-50%, -50%)',
                                backgroundColor: 'var( --color-blue-2)',
                                color: 'var(--color-blue-5)',
                                fontWeight: '500',
                                fontSize: '14px',
                                borderRadius: 'var(--radius-lg)',
                                opacity: 0,
                            },
                            '&:hover': {
                                '&::before': {
                                    backgroundColor: 'rgba(0, 0, 0, 0.1)',
                                    backdropFilter: 'blur(2px)',
                                },
                                '&::after': {
                                    opacity: 1
                                }
                            },
                        }} onClick={uploadFile} data-id={item.id}>
                        </Avatar>
                        <Box>
                            <Typography variant="h5" component="h5" fontWeight={'medium'}>{item.name}</Typography>
                            <Typography variant="p" color="textSecondary">{item.email}</Typography>
                            <Box className="flex gap-4 mt-6">
                                <Button type="button" variant="contained" color="primary" size="small" sx={{ px: 4, py: '12px' }} startIcon={<EditNoteOutlinedIcon />} onClick={editData} data-id={item.id}>Ubah Data</Button>
                                <Button type="button" variant="contained" color="error" size="small" sx={{ px: 4, py: '12px' }} startIcon={<CloseOutlinedIcon />} onClick={ConfirmDelete} data-id={item.id}>Hapus</Button>
                            </Box>
                        </Box>
                        <Box className="absolute top-4 right-4">
                            {item.status ?
                                <Chip label="Aktif" sx={{ borderRadius: 'var(--radius-md)', bgcolor: 'var(--color-green-1)', color: 'var(--color-green-2)', fontSize: '14px', fontWeight: '500' }} />
                                :
                                <Chip label="Non Aktif" sx={{ borderRadius: 'var(--radius-md)', bgcolor: 'var(--color-maroon-1)', color: 'var(--color-maroon-2)', fontSize: '14px', fontWeight: '500' }} />
                            }
                        </Box>
                    </Card>
                )}
            </Box>

            <Modal open={openDeleteModal} onClose={DeleteModal} className="flex items-center justify-center h-screen">
                <Box className="flex items-center justify-center h-screen">
                    <Box className="w-xl p-6 bg-white rounded-lg shadow-md">
                        <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                            Konfirmasi Hapus Data
                        </Typography>
                        <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>
                            Pengguna dengan nama
                            <Typography variant="span" component="span" align="center" fontWeight="bold" color="var(--color-black-3)"> {deleteId?.name} </Typography>
                            akan di hapus, data yang telah dihapus tidak dapat dipulihkan kembali, pilih batalkan jika tidak ingin menghapus
                        </Typography>
                        <Box className="w-full flex justify-end">
                            <Button variant="text" color="primary" onClick={DeleteModal}>Batalkan</Button>
                            <Button variant="text" color="error" onClick={deleteData}>Hapus</Button>
                        </Box>
                    </Box>
                </Box>
            </Modal>

            <Modal open={modalUploadFile} onClose={uploadFile} className="flex items-center justify-center h-screen">
                <Box className="w-4xl h-[500px] p-6 bg-white rounded-lg shadow-md flex flex-col justify-center relative">
                    <CloudUploadOutlinedIcon sx={{ fontSize: 100, color: 'var(--color-black-3)', display: 'block', mx: 'auto', mb: 3 }} />
                    <Typography variant="h5" component="h5" align="center" sx={{}}>Tarik dan Jatuhkan</Typography>
                    <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>FIle yang dapat di unggah bertipe png, jpg, jpeg</Typography>
                    <input type="file" name="" id="" className="w-full h-full absolute top-0 left-0 opacity-0" onChange={handleFile} />
                </Box>
            </Modal>
        </>
    )
}

export default Users