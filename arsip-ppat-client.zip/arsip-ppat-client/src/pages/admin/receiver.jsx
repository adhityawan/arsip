import { Box, Typography, Avatar, Button, TextField, Modal, Card } from "@mui/material"
import { useEffect, useState } from "react"
import FormReceiver from "./form-receiver";
import EditNoteOutlinedIcon from '@mui/icons-material/EditNoteOutlined';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import CloudUploadOutlinedIcon from '@mui/icons-material/CloudUploadOutlined';
import { deleteRecipient, getRecipient, uploadAvatarRecipient } from "../../request/receiver";
import Alerts from "../../components/alert";

const initialForm = {
    name: '',
    email: '',
    avatar: '',
    phone: '',
    province: '',
    city: '',
    subdistrict: '',
    ward: ''
}

const initialFormData = {
    id: ''
}

const Receiver = () => {
    const [openDeleteModal, setOpenDeleteModal] = useState(false)
    const [data, setData] = useState([])
    const [receivers, setReceivers] = useState([])
    const [deleteId, setDeleteId] = useState(null)
    const [openForm, setOpenForm] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [formData, setFormData] = useState(initialFormData)
    const [modalUploadFile, setModalUploadFile] = useState(false)
    const [msg, setMsg] = useState('')

    const getData = async () => {
        const receiver = await getRecipient()
        setData(receiver.data)
    }

    const search = (e) => {
        const { value } = e.target
        setReceivers(value ? data.filter(item => item.name.toLowerCase().includes(value.toLowerCase())).slice(0, 10) : data.slice(0, 10))
    }

    const DeleteModal = () => {
        setOpenDeleteModal(!openDeleteModal)
        deleteId && setDeleteId(null)
    }

    const ConfirmDelete = (e) => {
        setDeleteId(...receivers.filter(item => e.target.dataset.id.includes(item.id)))
        DeleteModal()
    }

    const deleteData = async () => {
        await deleteRecipient(deleteId.id)
        getData()
        DeleteModal()
    }

    const toggleFormReceiver = () => {
        setOpenForm(!openForm)
    }

    const formClose = () => {
        toggleFormReceiver()
        setForm(initialForm)
        getData()
    }

    const editData = (e) => {
        let forms = data.find((item) => item.id == e.target.dataset.id)
        setForm(forms)
        toggleFormReceiver()
    }

    const uploadFile = (e) => {
        setFormData({ ...formData, id: e.target.dataset.id })
        setModalUploadFile(!modalUploadFile)
    }

    const handleFile = async (e) => {
        e.preventDefault()
        const file = e.target.files[0]
        const allowType = ['png', 'jpg', 'jpeg']
        const fileType = file.type.split('/').pop()

        if (file) {
            allowType.includes(fileType) ? setFormData({ ...formData, avatar: file }) : (() => {
                setMsg('file tidak sesuai')
            })()
        }
    }

    useEffect(() => {
        setReceivers(data.slice(0, 10))
    }, [data])

    useEffect(() => {
        if (formData.avatar) {
            uploadAvatarRecipient(formData).then(() => {
                getData()
                setFormData(initialFormData)
                setModalUploadFile(!modalUploadFile)
            })
        }
    }, [formData])

    useEffect(() => {
        getData()
    }, [])

    return (
        openForm ? <FormReceiver form={form} onClose={formClose} /> : <>
            <Alerts status={'error'}>{msg}</Alerts>
            <Box className="flex flex-col max-w-5xl gap-4 mx-auto relative">
                <Box className="flex justify-between items-center gap-4 sticky top-[68px] z-10 bg-[var(--color-grey-1)] py-4 ">
                    <TextField id="number" name="number" type="text" fullWidth variant="outlined" label="Cari nama penerima" onChange={search} />
                    <Button type="button" variant="contained" color="primary" size="small" sx={{ py: '16.5px', px: 4, textWrap: 'nowrap' }} onClick={toggleFormReceiver}>Buat Penerima</Button>
                </Box>
                {receivers.map((item) =>
                    <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="flex gap-8 py-4 px-8" key={item.id} >
                        <Avatar src={item.avatar} sx={{
                            position: 'relative', width: '150px', height: '150px', borderRadius: 1, cursor: 'pointer',
                            '&::before': {
                                content: '""',
                                position: 'absolute',
                                top: 0,
                                left: 0,
                                width: '100%',
                                height: '100%',
                                transition: 'all ease-in-out 0.3s'
                            },
                            '&::after': {
                                content: `'Ubah'`,
                                position: 'absolute',
                                top: '50%',
                                left: '50%',
                                width: 'fit-content',
                                height: 'fit-content',
                                padding: '10px 18px',
                                transition: 'all ease-in-out 0.3s',
                                transform: 'translate(-50%, -50%)',
                                backgroundColor: 'var( --color-blue-2)',
                                color: 'var(--color-blue-5)',
                                fontWeight: '500',
                                fontSize: '14px',
                                borderRadius: 'var(--radius-lg)',
                                opacity: 0,
                            },
                            '&:hover': {
                                '&::before': {
                                    backgroundColor: 'rgba(0, 0, 0, 0.1)',
                                    backdropFilter: 'blur(2px)',
                                },
                                '&::after': {
                                    opacity: 1
                                }
                            },
                        }} onClick={uploadFile} data-id={item.id}>
                        </Avatar>
                        <Box>
                            <Typography variant="h5" component="h5" fontWeight={'medium'}>{item.name}</Typography>
                            <Typography variant="p" color="textSecondary">{item.email}</Typography>
                            <Box className="flex gap-4 mt-6">
                                <Button type="button" variant="contained" color="primary" size="small" sx={{ px: 4, py: '12px' }} startIcon={<EditNoteOutlinedIcon />} onClick={editData} data-id={item.id}>Ubah Data</Button>
                                <Button type="button" variant="contained" color="error" size="small" sx={{ px: 4, py: '12px' }} startIcon={<CloseOutlinedIcon />} onClick={ConfirmDelete} data-id={item.id}>Hapus</Button>
                            </Box>
                        </Box>
                    </Card>
                )}
            </Box>

            <Modal open={openDeleteModal} onClose={DeleteModal} className="flex items-center justify-center h-screen">
                <Box className="flex items-center justify-center h-screen">
                    <Box className="w-xl p-6 bg-white rounded-lg shadow-md">
                        <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                            Konfirmasi Hapus Data
                        </Typography>
                        <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>
                            Penerima dengan nama
                            <Typography variant="span" component="span" align="center" fontWeight="bold" color="var(--color-black-3)"> {deleteId?.name} </Typography>
                            akan di hapus, data yang telah dihapus tidak dapat dipulihkan kembali, pilih batalkan jika tidak ingin menghapus
                        </Typography>
                        <Box className="w-full flex justify-end">
                            <Button variant="text" color="primary" onClick={DeleteModal}>Batalkan</Button>
                            <Button variant="text" color="error" onClick={deleteData}>Hapus</Button>
                        </Box>
                    </Box>
                </Box>
            </Modal>

            <Modal open={modalUploadFile} onClose={uploadFile} className="flex items-center justify-center h-screen">
                <Box className="w-4xl h-[500px] p-6 bg-white rounded-lg shadow-md flex flex-col justify-center relative">
                    <CloudUploadOutlinedIcon sx={{ fontSize: 100, color: 'var(--color-black-3)', display: 'block', mx: 'auto', mb: 3 }} />
                    <Typography variant="h5" component="h5" align="center" sx={{}}>Tarik dan Jatuhkan</Typography>
                    <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>FIle yang dapat di unggah bertipe png, jpg, jpeg</Typography>
                    <input type="file" accept="image/png, image/jpeg, image/jpg" className="w-full h-full absolute top-0 left-0 opacity-0" onChange={handleFile} />
                </Box>
            </Modal>
        </>
    )
}

export default Receiver