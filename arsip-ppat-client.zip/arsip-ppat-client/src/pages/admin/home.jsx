import { Box, Typography, Card } from "@mui/material";
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import ChecklistOutlinedIcon from '@mui/icons-material/ChecklistOutlined';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import MarkEmailReadOutlinedIcon from '@mui/icons-material/MarkEmailReadOutlined';
import { Link } from "react-router";
import { useEffect, useState } from "react";
import { getUser } from "../../request/user";
import { getArchive } from "../../request/archive";
import { getRecipient } from "../../request/receiver";
import { getCategory } from "../../request/category";

const Home = () => {
    const [user, setUser] = useState(0)
    const [archive, setArchive] = useState(0)
    const [category, setCategory] = useState(0)
    const [receiver, setReceiver] = useState(0)

    const getData = async () => {
        const user = await getUser()
        const archive = await getArchive()
        const category = await getCategory()
        const receiver = await getRecipient()
        user.data && setUser(user.data.length)
        archive.data && setArchive(archive.data.length)
        category.data && setCategory(category.data.length)
        receiver.data && setReceiver(receiver.data.length)
    }

    useEffect(() => {
        getData()
    }, [])

    return (
        <>
            <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(12, minmax(0, 1fr))', gap: 2 }}>
                <Box sx={{ gridColumn: { lg: 'span 6', xs: 'span 12' } }} className="w-full">
                    <img src="/img/welcome-card.png" alt="" className="w-full rounded-xl" />
                </Box>
                <Box sx={{ gridColumn: { lg: 'span 6', xs: 'span 12' }, display: 'grid', gridTemplateColumns: { md: 'repeat(2, minmax(0, 1fr))', xs: 'repeat(1, minmax(0, 1fr))' }, gap: 2 }} className="w-full">
                    <Card component={Link} to={'/archive/users'} sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="flex items-center lg:justify-center lg:flex-col gap-4  p-4 xl:p-6" elevation={0} >
                        <Box className="bg-[var(--color-blue-2)] rounded-full inline-block p-2 xl:p-4">
                            <PeopleAltOutlinedIcon sx={{ fontSize: { xs: 40, xl: 50 }, color: 'var(--color-blue-3)' }} />
                        </Box>
                        <Box className="lg:text-center">
                            <Typography component="h5" fontWeight={'bold'} sx={{ fontSize: { xs: 20, md: 25, xl: 40 } }}>{user}</Typography>
                            <Typography component="span">Pengelola Arsip</Typography>
                        </Box>
                    </Card>
                    <Card component={Link} to={'/archive/manage'} sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="flex items-center lg:justify-center lg:flex-col gap-4  p-4 xl:p-6" elevation={0} >
                        <Box className="bg-[var(--color-orange-1)] rounded-full inline-block p-2 xl:p-4">
                            <ArchiveOutlinedIcon sx={{ fontSize: { xs: 40, xl: 50 }, color: 'var(--color-orange-2)' }} />
                        </Box>
                        <Box className="lg:text-center">
                            <Typography component="h5" fontWeight={'bold'} sx={{ fontSize: { xs: 20, md: 25, xl: 40 } }}>{archive}</Typography>
                            <Typography component="span">Arsip Surat</Typography>
                        </Box>
                    </Card>
                    <Card component={Link} to={'/archive/category'} sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="flex items-center lg:justify-center lg:flex-col gap-4  p-4 xl:p-6" elevation={0} >
                        <Box className="bg-[var(--color-blue-2)] rounded-full inline-block p-2 xl:p-4">
                            <ChecklistOutlinedIcon sx={{ fontSize: { xs: 40, xl: 50 }, color: 'var(--color-blue-3)' }} />
                        </Box>
                        <Box className="lg:text-center">
                            <Typography component="h5" fontWeight={'bold'} sx={{ fontSize: { xs: 20, md: 25, xl: 40 } }}>{category}</Typography>
                            <Typography component="span">Jenis Akta</Typography>
                        </Box>
                    </Card>
                    <Card component={Link} to={'/archive/receiver'} sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="flex items-center lg:justify-center lg:flex-col gap-4  p-4 xl:p-6" elevation={0} >
                        <Box className="bg-[var(--color-orange-1)] rounded-full inline-block p-2 xl:p-4">
                            <MarkEmailReadOutlinedIcon sx={{ fontSize: { xs: 40, xl: 50 }, color: 'var(--color-orange-2)' }} />
                        </Box>
                        <Box className="lg:text-center">
                            <Typography component="h5" fontWeight={'bold'} sx={{ fontSize: { xs: 20, md: 25, xl: 40 } }}>{receiver}</Typography>
                            <Typography component="span">Penerima Surat</Typography>
                        </Box>
                    </Card>
                </Box>
            </Box>
        </>
    );
};

export default Home;
