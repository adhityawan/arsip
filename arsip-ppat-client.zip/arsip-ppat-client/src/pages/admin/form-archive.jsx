import { CircularProgress, Autocomplete, Box, Button, Card, IconButton, MenuItem, Modal, Select, TextField, Typography } from "@mui/material"
import { file } from "../../request/dummy"
import { useEffect, useState } from "react"
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers"
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import dayjs from "dayjs"
import DataTable from "../../components/table"
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined'
import UploadFileOutlinedIcon from '@mui/icons-material/UploadFileOutlined'
import { converInputDate } from "../../utils/functions"
import { getCategory } from "../../request/category"
import { getRecipient } from "../../request/receiver"
import Alerts from "../../components/alert"
import { DELEY_TIME } from "../../utils/config"
import { addArchive, updateArchive } from "../../request/archive"
import { addArchiveFile, deleteArchiveFile, downloadFile, getArchiveFile } from "../../request/archive-file"
import DownloadingRoundedIcon from '@mui/icons-material/DownloadingRounded';

const initialFormFile = {
    id_archive: ''
}

const FormArchive = ({ form, onClose }) => {
    const [formData, setFormData] = useState(form)
    const [formFile, setFormFile] = useState(initialFormFile)
    const [loading, setLoading] = useState(false)
    const [dataFile, setDataFile] = useState([])
    const [deleteId, setDeleteId] = useState([])
    const [modalConfirmDelete, setModalConfirmDelete] = useState(false)
    const [modalUploadFile, setModalUploadFile] = useState(false)
    const [category, setCategory] = useState([])
    const [receiver, setReceiver] = useState([])
    const [msg, setMsg] = useState('')


    const columns = [
        { label: "Nama File", key: "filename" },
        { label: "Pengunggah", key: "owner" }
    ]

    const dataSelected = (ids) => {
        ids.length > 0 ? setDeleteId(ids) : setDeleteId([])
    }

    const getData = async () => {
        const category = await getCategory()
        const receiver = await getRecipient()
        setCategory(category.data)
        setReceiver(receiver.data)
    }

    const getDataFile = async () => {
        if (form.id) {
            const file = await getArchiveFile({ id: form.id })
            setDataFile(file.data)
        }
    }

    const backTolist = () => {
        onClose()
    }

    const save = async (e) => {
        e.preventDefault()
        setLoading(true)

        const { status, message } = await (formData.id ? updateArchive({ ...formData }) : addArchive({ ...formData }))

        if (status == 'success') {
            setLoading(false)
            onClose()
        } else {
            setMsg(message)
            setLoading(false)
        }
    }

    const uploadFile = () => {
        setFormFile({ ...formFile, id_archive: form.id })
        setModalUploadFile(!modalUploadFile)
    }

    const handleFile = (e) => {
        e.preventDefault()
        const file = e.target.files[0]
        const allowType = ['pdf', 'doc', 'docx']
        const fileType = file.name.split('.').pop()

        if (file) {
            allowType.includes(fileType) ? setFormFile({ ...formFile, file: file }) : (() => {
                setMsg('file tidak sesuai')
            })()
        }
    }

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value })
    }

    const deleteData = async () => {
        const promises = deleteId.map(async (item) => {
            const { status, message } = await deleteArchiveFile(item)
            return status != 'success' && message
        })

        const messages = await Promise.all(promises)
        messages.filter(item => item).length > 0 && setMsg(messages.join(', '))

        getDataFile()
        setDeleteId([])
        confirmDelete()
    }

    const confirmDelete = () => {
        setModalConfirmDelete(!modalConfirmDelete)
    }

    const download = async (id) => {
        const { file, filename } = dataFile.find(item => item.id == id)
        const res = await downloadFile(file)

        if (res instanceof Blob) {
            const url = window.URL.createObjectURL(new Blob([res]));
            const link = document.createElement('a');

            link.href = url;
            link.setAttribute('download', filename);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } else {
            setMsg('Gagal mengunduh file')
        }
    }

    useEffect(() => {
        setDataFile(file.filter(item => form.id === item.id_archive))
        setFormData(prev => ({
            ...prev,
            date: prev.date || converInputDate(new Date()),
            accepted: prev.accepted || converInputDate(new Date()),
        }))
    }, [form])

    useEffect(() => {
        if (formFile.file) {
            addArchiveFile(formFile).then(() => {
                getDataFile()
                setFormFile(initialFormFile)
                setModalUploadFile(!modalUploadFile)
            })
        }
    }, [formFile])

    useEffect(() => {
        if (parseInt(formData.id_recipient)) {
            const recipient = receiver.find(item => item.id == formData.id_recipient)
            setFormData({ ...formData, address: recipient?.city })
        }
    }, [formData?.id_recipient])

    useEffect(() => {
        setTimeout(() => {
            setMsg('')
        }, DELEY_TIME)
    }, [msg])

    useEffect(() => {
        getDataFile()
        getData()
    }, [])

    return (
        <>
            <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="p-10" elevation={0} >
                <form onSubmit={save}>
                    <header className='flex gap-4 mb-10'>
                        <IconButton variant={'outline'} onClick={backTolist} ><ArrowCircleLeftOutlinedIcon fontSize="large" /></IconButton>
                        <Box>
                            <Typography variant="h4" component="h4" sx={{ mb: 1 }}>Arsip Surat</Typography>
                            <Typography variant="p" component="p">Memastikan setiap dokumen berharga terlindungi, terkelola dengan baik dan mudah diakses</Typography>
                        </Box>
                    </header>

                    <Alerts status={'error'}>{msg}</Alerts>

                    <Box className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-10">
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="number" >Nomor Akta</label>
                            <TextField id="number" name="number" type="text" fullWidth variant="outlined" value={formData.number} onChange={handleChange} />
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="date" >Tanggal Dibuat</label>
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker
                                    id="date" format="DD-MM-YYYY"
                                    value={dayjs(new Date(formData.date))}
                                    onChange={(value) => { setFormData({ ...formData, date: converInputDate(value.toDate()) }) }}
                                />
                            </LocalizationProvider>
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="regarding" >Perihal</label>
                            <TextField id="regarding" name="regarding" type="text" fullWidth variant="outlined" value={formData.regarding} onChange={handleChange} />
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="category" >Jenis Akta</label>
                            <Autocomplete
                                options={[...category]}
                                getOptionLabel={(option) => option.category}
                                onChange={(_, v) => handleChange({ target: { name: 'id_category', value: v ? v.id : '' } })}
                                renderInput={(params) => <TextField {...params} />}
                                defaultValue={formData?.id > 0 ? { id: formData.id_category, category: formData.category } : null}
                                fullWidth
                            />
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="recipient" >Nama Penerima</label>
                            <Autocomplete
                                options={[...receiver]}
                                getOptionLabel={options => options.name}
                                onChange={(_, v) => handleChange({ target: { name: 'id_recipient', value: v ? v.id : '' } })}
                                renderInput={(params) => <TextField {...params} />}
                                defaultValue={formData?.id > 0 ? { id: formData.id_recipient, name: formData?.recipient } : null}
                                fullWidth
                            />
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="address" >Alamat Penerima</label>
                            <TextField id="address" name="address" type="text" fullWidth variant="outlined" value={formData.address} aria-readonly />
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="accepted" >Tanggal Diterima</label>
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker
                                    id="accepted" format="DD-MM-YYYY"
                                    value={dayjs(new Date(formData.accepted))}
                                    onChange={(value) => { setFormData({ ...formData, accepted: converInputDate(value.toDate()) }) }}
                                />
                            </LocalizationProvider>
                        </Box>
                        <Box className="flex flex-col gap-2">
                            <label component='label' htmlFor="status" >Status</label>
                            <Select id="status" name="status" type="text" fullWidth variant="outlined" value={formData.status} onChange={handleChange} >
                                <MenuItem value={true}>Telah Diterima</MenuItem>
                                <MenuItem value={false}>Belum Diterima</MenuItem>
                            </Select>
                        </Box>
                    </Box>

                    {(dataFile.length > 0 || form.id) && <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg), var(--shadow-min-lg)' }} className="pt-4 mb-10" elevation={0} >
                        <Box className="flex items-center justify-between mb-4 px-4">
                            <Typography variant="h6" component="h6">Detail Arsip Surat</Typography>
                            {deleteId.length > 0 ? <Button type="button" variant="contained" color="error" sx={{ px: 4 }} onClick={confirmDelete}>
                                Hapus
                            </Button> : <Button type="button" variant="contained" color="primary" sx={{ px: 4 }} onClick={uploadFile}>
                                Unggah
                            </Button>}
                        </Box>
                        <DataTable datas={{ columns, data: dataFile }} selectable={{ target: 'id', onSelect: dataSelected }} action={{
                            download: { icon: <DownloadingRoundedIcon />, label: 'Ubah', onClick: download, callBack: 'id' }
                        }} />
                    </Card>}
                    <Box className="flex justify-end w-full">
                        <Button type="submit" variant="contained" color="primary" sx={{ px: 4 }}>
                            {loading ? <CircularProgress color="inherit" size={20} /> : 'Simpan'}
                        </Button>
                    </Box>
                </form>
            </Card>

            <Modal open={modalConfirmDelete} onClose={confirmDelete} >
                <Box className="flex items-center justify-center h-screen">
                    <Box className="w-xl p-6 bg-white rounded-lg shadow-md">
                        <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                            Konfirmasi Hapus Data
                        </Typography>
                        <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>
                            Yakin ingin mengapus
                            <Typography variant="span" component="span" align="center" fontWeight="bold" text color="var(--color-black-3)" sx={{ fontStyle: 'italic' }}> File yang terpilih </Typography>
                            Data yang sudah di hapus tidak dapat dipulihkan kembali, batalkan jika anda tidak yakin dengan aksi ini.
                        </Typography>
                        <Box className="w-full flex justify-end">
                            <Button variant="text" color="primary" onClick={confirmDelete}>Batalkan</Button>
                            <Button variant="text" color="error" onClick={deleteData}>Hapus</Button>
                        </Box>
                    </Box>
                </Box>
            </Modal>

            <Modal open={modalUploadFile} onClose={uploadFile} className="flex items-center justify-center h-screen">
                <Box className="w-4xl h-[500px] p-6 bg-white rounded-lg shadow-md flex flex-col justify-center relative">
                    <UploadFileOutlinedIcon sx={{ fontSize: 100, color: 'var(--color-black-3)', display: 'block', mx: 'auto', mb: 3 }} />
                    <Typography variant="h5" component="h5" align="center" sx={{}}>Tarik dan Jatuhkan</Typography>
                    <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>FIle yang dapat di unggah bertipe pdf, doc, docx</Typography>
                    <input type="file" accept=".pdf, .doc, .docx" name="" id="" className="w-full h-full absolute top-0 left-0 opacity-0" onChange={handleFile} />
                </Box>
            </Modal>
        </>
    )
}

export default FormArchive