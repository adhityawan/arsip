import { Box, Button, Card, CircularProgress, Drawer, InputAdornment, Modal, TextField, Typography } from "@mui/material"
import { useEffect, useState } from 'react'
import { delay } from '../../utils/functions'
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined'
import KeyboardDoubleArrowRightOutlinedIcon from '@mui/icons-material/KeyboardDoubleArrowRightOutlined'
import DataTable from "../../components/table"
import FormArchive from "./form-archive"
import { deleteArchive, getArchive } from "../../request/archive"
import Alerts from "../../components/alert"
import { DELEY_TIME } from "../../utils/config"

const initialForm = {
    number: "",
    date: "",
    category: "",
    regarding: "",
    recipient: "",
    address: "",
    accepted: "",
    status: "",
    id_category: "",
    id_recipient: "",
}

const Category = () => {
    const [data, setData] = useState([])
    const [keyword, setKeyword] = useState('')
    const [drawer, setDrawer] = useState(false)
    const [modal, setModal] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [openForm, setOpenForm] = useState(false)
    const [loading, setLoading] = useState(false)
    const [deleteId, setDeleteId] = useState([])
    const [msg, setMsg] = useState('')


    const columns = [
        { label: "Nomor", key: "number" },
        { label: "Penerima", key: "recipient" },
        { label: "Tanggal", key: "date" },
        { label: "Perihal", key: "regarding" },
        { label: "Jenis", key: "category" },
    ]

    const dataSelected = (id) => {
        id.length > 0 ? id.forEach((item) => {
            setDeleteId([...deleteId, item])
        }) : setDeleteId([])
    }

    const getData = async () => {
        const archive = await getArchive()
        setData(archive.data)

    }

    const research = (e) => {
        setKeyword(e.target.value)
    }

    const formCategory = (e) => {
        e.preventDefault()
        setLoading(!loading)

        delay(1000).then(() => {
            setLoading(!loading)
            drawerClose()
        })
    }

    const setInputCategory = (e) => {
        e.preventDefault()
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    const deleteData = async () => {
        const promises = deleteId.map(async (item) => {
            const { status, message } = await deleteArchive(item)
            return status != 'success' && message
        })

        const messages = await Promise.all(promises)
        messages.filter(item => item).length > 0 && setMsg(messages.join(', '))

        getData()
        setDeleteId([])
        confirmDelete()
    }

    const confirmDelete = () => {
        setModal(!modal)
    }

    const drawerClose = () => {
        !loading && setDrawer(false)
        setForm(initialForm)
    }

    const toggleFormArchive = () => {
        setOpenForm(!openForm)
    }

    const formClose = () => {
        toggleFormArchive()
        setForm(initialForm)
        getData()
    }

    const editData = (id) => {
        let forms = data.find((item) => item.id == id)
        setForm(forms)
        toggleFormArchive()
    }

    useEffect(() => { getData() }, [])

    useEffect(() => {
        setTimeout(() => {
            setMsg('')
        }, DELEY_TIME)
    }, [msg])

    return (
        openForm ? <FormArchive form={form} onClose={formClose} /> : <>
            <header className='mb-10'>
                <Typography variant="h4" component="h4" sx={{ mb: 1 }}>Arsip Surat</Typography>
                <Typography variant="p" component="p">Memastikan setiap dokumen berharga terlindungi, terkelola dengan baik dan mudah diakses</Typography>
            </header>

            <Alerts status={'error'}>{msg}</Alerts>

            <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="pt-4" elevation={0} >
                <Box className="mb-4 px-4">
                    <Box className="flex items-center justify-between">
                        <TextField type="email" variant="outlined" onChange={research} placeholder="Cari jenis akta" slotProps={{
                            input: {
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchOutlinedIcon />
                                    </InputAdornment>
                                ),
                            },
                        }} />

                        {deleteId.length > 0 ? <Button type="button" variant="contained" color="error" sx={{ my: '15px', bgcolor: 'var(--color-maroon-1)' }} onClick={confirmDelete}>
                            Hapus Data
                        </Button> : <Button type="button" variant="contained" color="primary" sx={{ my: '15px' }} onClick={toggleFormArchive} >
                            Buat Arsip
                        </Button>}
                    </Box>
                </Box>
                <DataTable datas={{ columns, data }} selectable={{ target: 'id', onSelect: dataSelected }} search={keyword} action={{
                    edit: { icon: <KeyboardDoubleArrowRightOutlinedIcon />, label: 'Ubah', onClick: editData, callBack: 'id' }
                }} />
            </Card>

            <Drawer anchor="right" open={drawer} onClose={drawerClose} elevation={0} >
                <Box className="px-8 py-10 w-md">
                    <Typography variant='h5' component='h5' sx={{ mb: 4 }}>Tambah Jenis Surat</Typography>
                    <form onSubmit={formCategory}>
                        <Box className="flex flex-col gap-2 mb-6">
                            <label component='label' htmlFor="category" >Jenis Baru</label>
                            <TextField id="category" name="category" type="text" fullWidth variant="outlined" value={form.category} onChange={setInputCategory} />
                        </Box>
                        <Box className="flex flex-col gap-2 mb-6">
                            <label component='label' htmlFor="description" >Keterangan</label>
                            <TextField id="description" name="description" type="text" fullWidth variant="outlined" multiline rows={8} value={form.description} onChange={setInputCategory} />
                        </Box>
                        <Box className="flex justify-end gap-2 mb-6">
                            <Button type="submit" variant="contained" color="primary" loadingPosition="center" loadingIndicator={<CircularProgress color="primary" size={20} />} loading={loading}>
                                Tambah Jenis
                            </Button>
                        </Box>
                    </form>
                </Box>
            </Drawer>

            <Modal open={modal} onClose={confirmDelete} >
                <Box className="flex items-center justify-center h-screen">
                    <Box className="w-xl p-6 bg-white rounded-lg shadow-md">
                        <Typography variant="h5" component="h5" align="center" sx={{ mb: 3 }}>
                            Konfirmasi Hapus Data
                        </Typography>
                        <Typography variant="p" component="p" align="center" sx={{ mb: 2 }}>
                            Yakin
                            <Typography variant="span" component="span" align="center" fontWeight="bold" color="var(--color-black-3)"> Arsip Akta yang terpilih </Typography>
                            akan di hapus, data yang telah dihapus tidak dapat dipulihkan kembali, pastikan anda yakin untuk menghapusnya
                        </Typography>
                        <Box className="w-full flex justify-end">
                            <Button variant="text" color="primary" onClick={confirmDelete}>Batalkan</Button>
                            <Button variant="text" color="error" onClick={deleteData}>Hapus</Button>
                        </Box>
                    </Box>
                </Box>
            </Modal>
        </>
    )
}

export default Category