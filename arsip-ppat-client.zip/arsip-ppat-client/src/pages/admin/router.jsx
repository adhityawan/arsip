import { Routes, Route } from "react-router";
import Home from "./home";
import Category from "./catagory";
import Archive from "./archive";
import Receiver from "./receiver";
import Users from "./users";

const Router = () => {
    return (
        <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/category" element={<Category />} />
            <Route path="/manage" element={<Archive />} />
            <Route path="/receiver" element={<Receiver />} />
            <Route path="/users" element={<Users />} />
        </Routes>
    );
}

export default Router;