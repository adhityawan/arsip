import { Autocomplete, Box, Button, Card, Checkbox, CircularProgress, FormControlLabel, IconButton, TextField, Typography } from "@mui/material"
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined'
import { useEffect, useState } from "react"
import { getCity, getProvince, getSubdistrict, getWard } from "../../request/address"
import { DELEY_TIME } from "../../utils/config"
import Alerts from "../../components/alert"
import { addUser, updateUser } from "../../request/user"

const FormUser = ({ form, onClose }) => {
    const [formData, setFormData] = useState(form)
    const [province, setProvince] = useState([])
    const [loading, setLoading] = useState(false)
    const [city, setCity] = useState([])
    const [subdistrict, setSubdistrict] = useState([])
    const [ward, setWard] = useState([])
    const [msg, setMsg] = useState('')

    const backTolist = () => {
        onClose()
    }

    const handleChange = (e) => {
        setFormData({
            ...formData, [e.target.name]:
                e.target.name == 'status' ? e.target.checked : e.target.value
        })
    }

    const save = async (e) => {
        e.preventDefault()
        if (formData.confirm_password && formData.confirm_password != formData.password) {
            setMsg('konfirmasi password tidak sama')
            return
        }

        const { status, message } = await (formData.id ? updateUser(formData) : addUser(formData))

        if (status == 'success') {
            setLoading(false)
            backTolist()
        } else {
            setMsg(message)
            setLoading(false)
        }

        setTimeout(() => {
            setMsg('')
        }, DELEY_TIME)
    }

    const allWard = async (id) => {
        const res = await getWard(id)
        setWard(res || [])
        return res || []
    }

    const allSubdistrict = async (id) => {
        const res = await getSubdistrict(id)
        setSubdistrict(res || [])
        return res || []
    }

    const allCity = async (id) => {
        const res = await getCity(id)
        setCity(res || [])
        return res || []
    }

    const allProvince = async () => {
        const res = await getProvince()
        setProvince(res || [])
    }

    const addressChange = (data) => {
        const { name, value, code } = data.target

        switch (name) {
            case "province":
                setFormData({ ...formData, province: value, city: '', subdistrict: '', ward: '' })
                allCity(code)
                break
            case "city":
                setFormData({ ...formData, city: value, subdistrict: '', ward: '' })
                allSubdistrict(code)
                break
            case "subdistrict":
                setFormData({ ...formData, subdistrict: value, ward: '' })
                allWard(code)
                break
            case "ward":
                setFormData({ ...formData, ward: value })
                break
            default:
                break
        }
    }

    useEffect(() => {
        if (formData?.id && province.length && formData?.province) {
            const selectProvince = province?.find(item => item.name == formData?.province)
            if (selectProvince) {
                allCity(selectProvince.code)
                    .then(items => items.find(item => item.name == formData?.city))
                    .then(selectCity => allSubdistrict(selectCity?.code))
                    .then(items => items.find(item => item.name == formData?.subdistrict))
                    .then(selectSubdistrict => allWard(selectSubdistrict?.code))
            }
        }
    }, [province])

    useEffect(() => { allProvince() }, [])
    return (
        <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="p-10" elevation={0} >
            <header className='flex gap-4 mb-10'>
                <IconButton variant={'outline'} onClick={backTolist} ><ArrowCircleLeftOutlinedIcon fontSize="large" /></IconButton>
                <Box>
                    <Typography variant="h4" component="h4" sx={{ mb: 1 }}>Tambah Pengguna</Typography>
                    <Typography variant="p" component="p">Pengguna bertindak sebagai pengelola aplikasi pengarsipan, tambahkan yang hanya anda percaya</Typography>
                </Box>
            </header>

            <Alerts status={'error'}>{msg}</Alerts>

            <form onSubmit={save}>
                <Box className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-10">
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="name" >Nama Lengkap</label>
                        <TextField id="name" name="name" type="text" fullWidth variant="outlined" value={formData?.name} onChange={handleChange} />
                    </Box>
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="phone" >Nomor Telepon</label>
                        <TextField id="phone" name="phone" type="text" fullWidth variant="outlined" value={formData?.phone} onChange={handleChange} />
                    </Box>
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="email" >Alamat Email</label>
                        <TextField id="email" name="email" type="text" fullWidth variant="outlined" value={formData?.email} onChange={handleChange} />
                    </Box>
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="province" >Provinsi</label>
                        <Autocomplete
                            id="province"
                            options={[...province]}
                            getOptionLabel={options => options.name}
                            onChange={(_, v) => addressChange({ target: { name: 'province', value: v ? v.name : '', code: v ? v.code : '' } })}
                            renderInput={(params) => <TextField {...params} />}
                            defaultValue={formData?.id > 0 ? { name: formData?.province } : { name: '' }}
                            fullWidth
                        />
                    </Box>
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="city" >Kab / Kota</label>
                        <Autocomplete
                            id="city"
                            options={[...city]}
                            getOptionLabel={options => options.name}
                            onChange={(_, v) => addressChange({ target: { name: 'city', value: v ? v.name : '', code: v ? v.code : '' } })}
                            renderInput={(params) => <TextField {...params} />}
                            defaultValue={formData?.id > 0 ? { name: formData?.city } : { name: '' }}
                            fullWidth
                        />
                    </Box>
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="subdistrict" >Kecamatan</label>
                        <Autocomplete
                            id="subdistrict"
                            options={[...subdistrict]}
                            getOptionLabel={options => options.name}
                            onChange={(_, v) => addressChange({ target: { name: 'subdistrict', value: v ? v.name : '', code: v ? v.code : '' } })}
                            renderInput={(params) => <TextField {...params} />}
                            defaultValue={formData?.id > 0 ? { name: formData?.subdistrict } : { name: '' }}
                            fullWidth
                        />
                    </Box>
                    <Box className="flex flex-col gap-2">
                        <label component='label' htmlFor="ward" >Kelurahan</label>
                        <Autocomplete
                            id="ward"
                            options={[...ward]}
                            getOptionLabel={options => options.name}
                            onChange={(_, v) => addressChange({ target: { name: 'ward', value: v ? v.name : '', code: v ? v.code : '' } })}
                            renderInput={(params) => <TextField {...params} />}
                            defaultValue={formData?.id > 0 ? { name: formData?.ward } : { name: '' }}
                            fullWidth
                        />
                    </Box>
                    <Box className="flex flex-col  justify-end">
                        <FormControlLabel label="Status" checked={formData?.status} id="status" name="status" onChange={handleChange} sx={{
                            '& .MuiTypography-root': {
                                fontSize: 18,
                                fontWeight: '500',
                                color: 'var(--color-black-3s)'
                            }
                        }} control={
                            <Checkbox color="primary" sx={{
                                '& .MuiSvgIcon-root': {
                                    fontSize: 28,
                                },
                            }} />
                        } />
                        <Typography component='label' htmlFor="Status" color="textSecondary" sx={{ fontSize: 12 }} >Status Aktif / Non Aktif, mengizinkan pengguna mesuk dalam aplikasi atau tidak</Typography>
                    </Box>
                </Box>

                {(!formData?.id && formData?.status) &&
                    <>
                        <header className='flex flex-col mb-8 mt-16'>
                            <Typography variant="h4" component="h4" sx={{ mb: 1 }}>Autentikasi</Typography>
                            <Typography variant="p" component="p">Kata sandi akan digunakan untuk pengguna masuk ke dalam aplikasi</Typography>
                        </header>

                        <Box className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
                            <Box className="flex flex-col gap-2">
                                <label component='label' htmlFor="password" >Kata Sandi</label>
                                <TextField id="password" name="password" type="password" fullWidth variant="outlined" value={formData.password} onChange={handleChange} />
                            </Box>
                            <Box className="flex flex-col gap-2">
                                <label component='label' htmlFor="confirm-password" >Konfirmasi Sandi</label>
                                <TextField id="confirm-password" name="confirm-password" type="password" fullWidth variant="outlined" value={formData.confirm_password} onChange={handleChange} />
                            </Box>
                        </Box>
                    </>
                }

                <Box className="flex flex-col items-end">
                    <Button type="submit" variant="contained" color="primary" size="small" sx={{ px: 4, py: 2, width: 'fit-content' }} >
                        {loading ? <CircularProgress color="inherit" size={20} /> : 'Simpan Pengguna'}
                    </Button>
                </Box>
            </form>
        </Card>
    )
}

export default FormUser