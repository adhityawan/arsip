import { Autocomplete, Box, Button, Card, CircularProgress, IconButton, TextField, Typography } from "@mui/material"
import { useEffect, useState } from "react"
import { getCity, getProvince, getSubdistrict, getWard } from "../../request/address"
import { addRecipient, updateRecipient } from "../../request/receiver"
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined'
import Alerts from "../../components/alert"
import { DELEY_TIME } from "../../utils/config"

const FormReceiver = ({ form, onClose }) => {
    const [formData, setFormData] = useState(form)
    const [loading, setLoading] = useState(false)
    const [province, setProvince] = useState([])
    const [city, setCity] = useState([])
    const [subdistrict, setSubdistrict] = useState([])
    const [ward, setWard] = useState([])
    const [msg, setMsg] = useState('')

    const backTolist = () => {
        onClose()
    }

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value })
    }

    const save = async (e) => {
        e.preventDefault()
        setLoading(true)
        const { status, message } = await (formData.id ? updateRecipient(formData) : addRecipient(formData))

        if (status == 'success') {
            setLoading(false)
            backTolist()
        } else {
            setMsg(message)
            setLoading(false)
        }

        setTimeout(() => {
            setMsg('')
        }, DELEY_TIME)
    }

    const allWard = async (id) => {
        const res = await getWard(id)
        setWard(res || [])
        return res || []
    }

    const allSubdistrict = async (id) => {
        const res = await getSubdistrict(id)
        setSubdistrict(res || [])
        return res || []
    }

    const allCity = async (id) => {
        const res = await getCity(id)
        setCity(res || [])
        return res || []
    }

    const allProvince = async () => {
        const res = await getProvince()
        setProvince(res || [])
    }

    const addressChange = (data) => {
        const { name, value, code } = data.target

        switch (name) {
            case "province":
                setFormData({ ...formData, province: value, city: '', subdistrict: '', ward: '' })
                allCity(code)
                break
            case "city":
                setFormData({ ...formData, city: value, subdistrict: '', ward: '' })
                allSubdistrict(code)
                break
            case "subdistrict":
                setFormData({ ...formData, subdistrict: value, ward: '' })
                allWard(code)
                break
            case "ward":
                setFormData({ ...formData, ward: value })
                break
            default:
                break
        }
    }

    useEffect(() => {
        if (formData?.id && province.length && formData?.province) {
            const selectProvince = province?.find(item => item.name == formData?.province)
            if (selectProvince) {
                allCity(selectProvince.code)
                    .then(items => items.find(item => item.name == formData?.city))
                    .then(selectCity => allSubdistrict(selectCity?.code))
                    .then(items => items.find(item => item.name == formData?.subdistrict))
                    .then(selectSubdistrict => allWard(selectSubdistrict?.code))
            }
        }
    }, [province])

    useEffect(() => { allProvince() }, [])

    return (
        <Card sx={{ borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)' }} className="p-10" elevation={0} >
            <header className='flex gap-4 mb-10'>
                <IconButton variant={'outline'} onClick={backTolist} ><ArrowCircleLeftOutlinedIcon fontSize="large" /></IconButton>
                <Box>
                    <Typography variant="h4" component="h4" sx={{ mb: 1 }}>{formData.id ? 'Ubah Data Penerima' : 'Tambah Penerima'}</Typography>
                    <Typography variant="p" component="p">Pastikan data yang di masukan benar, ini akan menjadi data pemilik surat</Typography>
                </Box>
            </header>

            <Alerts status={'error'}>{msg}</Alerts>

            <form className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-10" onSubmit={save} >
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="name" >Nama Lengkap</label>
                    <TextField id="name" name="name" type="text" fullWidth variant="outlined" value={formData.name} onChange={handleChange} />
                </Box>
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="phone" >Nomor Telepon</label>
                    <TextField id="phone" name="phone" type="text" fullWidth variant="outlined" value={formData.phone} onChange={handleChange} />
                </Box>
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="email" >Alamat Email</label>
                    <TextField id="email" name="email" type="email" fullWidth variant="outlined" value={formData.email} onChange={handleChange} />
                </Box>
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="province" >Provinsi</label>
                    <Autocomplete
                        id="province"
                        options={[...province]}
                        getOptionLabel={options => options.name}
                        onChange={(_, v) => addressChange({ target: { name: 'province', value: v ? v.name : '', code: v ? v.code : '' } })}
                        renderInput={(params) => <TextField {...params} />}
                        defaultValue={formData?.id > 0 ? { name: formData?.province } : { name: '' }}
                        fullWidth
                    />
                </Box>
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="city" >Kab / Kota</label>
                    <Autocomplete
                        id="city"
                        options={[...city]}
                        getOptionLabel={options => options.name}
                        onChange={(_, v) => addressChange({ target: { name: 'city', value: v ? v.name : '', code: v ? v.code : '' } })}
                        renderInput={(params) => <TextField {...params} />}
                        defaultValue={formData?.id > 0 ? { name: formData?.city } : { name: '' }}
                        fullWidth
                    />
                </Box>
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="subdistrict" >Kecamatan</label>
                    <Autocomplete
                        id="subdistrict"
                        options={[...subdistrict]}
                        getOptionLabel={options => options.name}
                        onChange={(_, v) => addressChange({ target: { name: 'subdistrict', value: v ? v.name : '', code: v ? v.code : '' } })}
                        renderInput={(params) => <TextField {...params} />}
                        defaultValue={formData?.id > 0 ? { name: formData?.subdistrict } : { name: '' }}
                        fullWidth
                    />
                </Box>
                <Box className="flex flex-col gap-2">
                    <label component='label' htmlFor="ward" >Kelurahan</label>
                    <Autocomplete
                        id="ward"
                        options={[...ward]}
                        getOptionLabel={options => options.name}
                        onChange={(_, v) => addressChange({ target: { name: 'ward', value: v ? v.name : '', code: v ? v.code : '' } })}
                        renderInput={(params) => <TextField {...params} />}
                        defaultValue={formData?.id > 0 ? { name: formData?.ward } : { name: '' }}
                        fullWidth
                    />
                </Box>
                <Box className="flex flex-col gap-2 justify-end items-end">
                    <Button type="submit" variant="contained" color="primary" size="small" sx={{ px: 4, py: 2, width: 'fit-content' }} >
                        {loading ? <CircularProgress color="inherit" size={20} /> : 'Simpan Penerima'}
                    </Button>
                </Box>
            </form>
        </Card>
    )
}

export default FormReceiver
