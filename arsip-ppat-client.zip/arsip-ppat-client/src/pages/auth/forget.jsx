import { Box, Button, CircularProgress, TextField, Typography } from "@mui/material";
import { Link, useNavigate } from "react-router";
import { useEffect, useState } from "react";
import { DELEY_TIME } from "../../utils/config";
import EastIcon from '@mui/icons-material/East';
import Alerts from "../../components/alert";
import { confirm, forget } from "../../request/auth";
import { addTokenResetPassword } from "../../utils/functions";

const initialForm = {
    email: "",
    otp: ""
}

const Forget = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [alert, setAlert] = useState({ message: '' })

    const sendMail = async (e) => {
        e.preventDefault()
        setLoading(true)

        const { status, message } = await forget({ email: form.email })
        if (status == 'success') {
            setAlert({ message, status })
            setLoading(false)
        } else {
            setAlert({ message, status: 'error' })
            setLoading(false)
        }
    }

    const verify = async (e) => {
        e.preventDefault()
        setLoading(true)

        const { status, message, data } = await confirm({ otp: form.otp })
        if (status == 'success') {
            setAlert({ message, status })
            addTokenResetPassword(data.token)
            navigate('/auth/reset');
        } else {
            setAlert({ message, status: 'error' })
            setLoading(false)
        }
    }

    const changeForm = (e) => {
        e.preventDefault()
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    useEffect(() => {
        setTimeout(() => {
            setAlert({ message: '' })
        }, DELEY_TIME)
    }, [alert])

    return (
        <Box className="bg-white rounded-2xl w-full max-w-[466px]" sx={{ padding: '78px 23px' }}>
            <Alerts status={alert.status} >{alert.message}</Alerts>
            <Typography variant="h4" component="h4" align="center" sx={{ mb: 1 }}> Lupa Sandi </Typography>
            <Typography variant="p" component="p" align="center"> OTP akan dikirimkan ke email terdaftar </Typography>
            <form className="my-[35px]" onSubmit={verify}>
                <Box className="flex gap-2">
                    <TextField onChange={changeForm} id="email" label="Alamat Email" type="email" name="email" fullWidth variant="outlined" sx={{ my: '15px' }} />
                    <Button type="button" variant="contained" color="primary" disabled={loading} sx={{ my: '15px' }} onClick={sendMail} >
                        {loading ? <CircularProgress color="inherit" size={20} /> : <EastIcon />}
                    </Button>
                </Box>
                <TextField onChange={changeForm} id="text" label="Kode OTP" type="text" name="otp" fullWidth variant="outlined" sx={{ my: '15px' }} />
                <Button type="submit" variant="contained" color="primary" disabled={loading} fullWidth sx={{ my: '15px' }} >
                    {loading ? <CircularProgress color="inherit" size={20} /> : 'Konfirmasi'}
                </Button>
            </form>
            <hr className="my-[35px] border-[#e4e4e4]" />
            <Box className="text-center font-medium">Ingat kata sandi &nbsp;
                <Link className="text-blue-4" to={'/'} >batalkan</Link>
            </Box>
        </Box>
    );
}

export default Forget;