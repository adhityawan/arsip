import { Box } from "@mui/material";
import Router from "./router";

const Layout = () => {
    return (
        <Box className="flex flex-col items-center justify-center h-screen wrapper-auth">
            <Router />
        </Box>
    );
}

export default Layout;