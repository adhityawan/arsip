import { Routes, Route } from "react-router";
import Login from "./login";
import Forget from "./forget";
import Reset from "./reset";

const Router = () => {
    return (
        <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/forget" element={<Forget />} />
            <Route path="/reset" element={<Reset />} />
        </Routes>
    );
}

export default Router;