import { Box, Button, CircularProgress, TextField, Typography } from "@mui/material";
import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { getToken, setToken } from "../../utils/functions";
import { useEffect } from "react";
import { login } from "../../request/auth";
import { DELEY_TIME } from "../../utils/config";
import Alerts from "../../components/alert";

const initialForm = {
    email: "",
    password: ""
}

const Login = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [msg, setMsg] = useState('')

    const signIn = async (e) => {
        e.preventDefault()
        setLoading(true)

        const { status, message, data } = await login(form)

        if (status == 'success') {
            setToken(data.token)
            setLoading(false)
            navigate('/archive')
        } else {
            setMsg(message)
            setLoading(false)
        }

        setTimeout(() => {
            setMsg('')
        }, DELEY_TIME)
    }

    const changeForm = (e) => {
        e.preventDefault()
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    useEffect(() => {
        const token = getToken()
        if (token) navigate('/archive')
    }, [navigate])

    return (
        <Box className="bg-white rounded-2xl w-full max-w-[466px]" sx={{ padding: '78px 23px' }}>
            <Alerts status={'error'}>{msg}</Alerts>
            <Typography variant="h4" component="h4" align="center" sx={{ mb: 1 }}> Arsip App </Typography>
            <Typography variant="p" component="p" align="center"> Masuk aplikasi pengarsipan </Typography>
            <form className="my-[35px]" onSubmit={signIn}>
                <TextField onChange={changeForm} id="email" label="Alamat Email" type="email" name="email" fullWidth variant="outlined" sx={{ my: '8px' }} />
                <TextField onChange={changeForm} id="password" label="kata Sandi" type="password" name="password" fullWidth variant="outlined" sx={{ my: '15px' }} />
                <Button type="submit" variant="contained" color="primary" fullWidth sx={{ my: '15px' }} >
                    {loading ? <CircularProgress color="inherit" size={20} /> : 'Masuk'}
                </Button>
            </form>
            <hr className="my-[35px] border-[#e4e4e4]" />
            <Box className="text-center font-medium">Lupa kata sandi &nbsp;
                <Link className="text-blue-4" to={'/auth/forget'} >Atur Ulang Sandi</Link>
            </Box>
        </Box>
    );
}

export default Login;