import { Box, Button, CircularProgress, TextField, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { getTokenResetPassword, removeTokenResetPassword } from "../../utils/functions";
import { reset } from "../../request/auth";
import { DELEY_TIME } from "../../utils/config";
import Alerts from "../../components/alert";

const initialForm = {
    password: "",
    confirm_password: ""
}

const Reset = () => {
    const navigate = useNavigate();
    const token = getTokenResetPassword()
    const [loading, setLoading] = useState(false)
    const [form, setForm] = useState(initialForm)
    const [alert, setAlert] = useState({ message: '' })

    const changePassword = async (e) => {
        e.preventDefault()
        setLoading(true)

        if (form.password == '') {
            setAlert({ message: 'Password tidak boleh kosong', status: 'error' })
            setLoading(false)
        } else if (form.password !== form.confirm_password) {
            setAlert({ message: 'Password dan konfirmasi password tidak sama', status: 'error' })
            setLoading(false)
        } else {
            const { status, message } = await reset({ token, password: form.password })
            if (status == 'success') {
                setAlert({ message, status })
                removeTokenResetPassword()
                navigate('/')
            } else {
                setAlert({ message, status: 'error' })
                setLoading(false)
            }
        }

        setTimeout(() => {
            setAlert({ message: '' })
        }, DELEY_TIME)
    }

    const changeForm = (e) => {
        e.preventDefault()
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    const cencled = () => {
        removeTokenResetPassword()
        navigate('/')
    }

    useEffect(() => {
        if (token) {
            setForm({ ...form, token })
        } else {
            navigate('/')
        }
    }, [token])

    return (
        <Box className="bg-white rounded-2xl w-full max-w-[466px]" sx={{ padding: '78px 23px' }}>
            <Alerts status={alert.status} >{alert.message}</Alerts>
            <Typography variant="h4" component="h4" align="center" sx={{ mb: 1 }}> Arsip App </Typography>
            <Typography variant="p" component="p" align="center"> Masuk aplikasi pengarsipan </Typography>
            <form className="my-[35px]">
                <TextField onChange={changeForm} id="password" label="Sandi Baru" type="password" name="password" fullWidth variant="outlined" sx={{ my: '15px' }} />
                <TextField onChange={changeForm} id="password" label="Konfirmasi Sandi" type="password" name="confirm_password" fullWidth variant="outlined" sx={{ my: '15px' }} />
                <Button variant="contained" color="primary" fullWidth sx={{ my: '15px' }} onClick={changePassword} >
                    {loading ? <CircularProgress color="inherit" size={20} /> : 'Simpan'}
                </Button>
            </form>
            <hr className="my-[35px] border-[#e4e4e4]" />
            <Box className="text-center font-medium">Ingat kata sandi &nbsp;
                <Box className="text-blue-4" component="button" onClick={cencled} >batalkan</Box>
            </Box>
        </Box>
    );
}

export default Reset;