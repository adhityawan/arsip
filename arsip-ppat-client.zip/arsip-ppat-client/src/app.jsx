import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProtectedRoute from "./utils/protectedRoute";
import Login from "./pages/auth";
import Home from "./pages/admin";
import NotFound from "./pages/error/not-found";


const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/auth/*" element={<Login />} />

        {/* Rute yang dilindungi login */}
        <Route element={<ProtectedRoute />}>
          <Route path="/archive/*" element={<Home />}/>
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
