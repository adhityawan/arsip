import { Box, Button, Checkbox, ListItemIcon, MenuItem, Paper, TablePagination, TableSortLabel } from "@mui/material"
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material"
import { useEffect, useState } from "react"
import MoreVertOutlinedIcon from '@mui/icons-material/MoreVertOutlined'
import Dropdown from "./drobdown"

const DataTable = ({ datas, selectable, action, search }) => {
    const { columns, data } = datas
    const { target, onSelect } = selectable
    const act = Object.entries(action).map(([key, value]) => ({ key, ...value }))

    const [page, setPage] = useState(0)
    const [rowsPerPage, setRowsPerPage] = useState(5)
    const [visibleRows, setVisibleRows] = useState(data)
    const [count, setCount] = useState(data.length)
    const [ordering, setOrdering] = useState(Object.fromEntries(
        columns.map(column => [column.key, 'asc'])
    ))

    const [selected, setSelected] = useState([])


    const handleSelect = (key) => {
        setSelected(selected.includes(key) ? selected.filter((item) => item !== key) : [...selected, key])
    }

    const handleSelectAll = () => {
        setSelected(selected.length === data.length ? [] : data.map((item) => item[target]))
    }

    const pagination = (rows) => {
        const startIndex = page * rowsPerPage
        const endIndex = page * rowsPerPage + rowsPerPage
        setVisibleRows(rows.slice(startIndex, endIndex))
    }

    const research = () => {
        setPage(0)
        const filtering = data.filter((item) => columns.some(col => String(item[col.key]).toLowerCase().includes(search.toLowerCase())))
        setCount(filtering.length > rowsPerPage ? filtering.length : rowsPerPage)
        pagination(filtering)
    }

    const sortData = (key) => {
        const order = ordering[key]

        order === 'asc' && data.sort((a, b) => { return a[key] > b[key] ? 1 : a[key] < b[key] ? -1 : 0 })
        order === 'desc' && data.sort((a, b) => { return a[key] < b[key] ? 1 : a[key] > b[key] ? -1 : 0 })

        pagination(data)
        setOrdering({ ...ordering, [key]: order === 'asc' ? 'desc' : 'asc' })
    }

    useEffect(() => {
        onSelect(selected)
    }, [selected])
    
    useEffect(() => {
        setSelected([])
    }, [data])
    
    useEffect(() => {
        search ? research() : (() => {
            pagination(data)
            setCount(data.length)
        })()
    }, [page, rowsPerPage, search, data])

    return (
        <TableContainer component={Paper} elevation={0}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ padding: '8px 6px', bgcolor: 'var(--color-grey-2)', width: 50 }}>
                            <Checkbox
                                color="primary"
                                checked={selected.length === data.length}
                                onChange={handleSelectAll}
                            />
                        </TableCell>
                        {columns.map((colomn) => (
                            <TableCell key={colomn.key} sx={{ padding: '8px 6px', bgcolor: 'var(--color-grey-2)', fontWeight: 600 }}>
                                <TableSortLabel onClick={() => sortData(colomn.key)}>
                                    {colomn.label}
                                </TableSortLabel>
                            </TableCell>
                        ))}
                        {act.length > 0 && <TableCell sx={{ padding: '8px 6px', bgcolor: 'var(--color-grey-2)', width: 100 }} />}
                    </TableRow>
                </TableHead>
                <TableBody>
                    {visibleRows.map((row, index) => (
                        <TableRow key={index} hover={true}>
                            <TableCell sx={{ padding: '4px 6px' }}>
                                <Checkbox
                                    color="primary"
                                    checked={selected.includes(row[target])}
                                    onChange={() => handleSelect(row[target])}
                                />
                            </TableCell>
                            {columns.map((colomn) => (
                                <TableCell key={colomn.key} sx={{ padding: '4px 6px' }}>{row[colomn.key] || '-'}</TableCell>
                            ))}
                            {act.length > 1 && <TableCell sx={{ padding: '4px 6px', width: 50 }}>
                                <Dropdown trigger={<MoreVertOutlinedIcon sx={{ color: 'var(--color-grey-4)' }} />}>
                                    {act.map((actItem) => (
                                        <MenuItem key={actItem.key} onClick={() => actItem.onClick(actItem.callBack && row[actItem.callBack])} sx={{ borderRadius: 1, '&:hover': { bgcolor: 'var(--color-blue-2)' }, '&:active': { bgcolor: 'var(--color-blue-2)' } }}>
                                            <ListItemIcon fontSize="small">{actItem.icon}</ListItemIcon>
                                            {actItem.label}
                                        </MenuItem>
                                    ))}
                                </Dropdown>
                            </TableCell>}
                            {act.length == 1 && <TableCell sx={{ padding: '4px 6px', width: 50, textAlign: 'right' }}>
                                <Button type="button" onClick={() => act[0].onClick(act[0].callBack && row[act[0].callBack])} color="inherit" variant="text" sx={{ color: 'var(--color-grey-4)' }}>
                                    {act[0].icon}
                                </Button>
                            </TableCell>}
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
            <TablePagination
                labelRowsPerPage="Baris per halaman"
                rowsPerPageOptions={[5, 10, 25, 50, 75, 100]}
                component={Box}
                count={count}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={(_, newPage) => setPage(newPage)}
                onRowsPerPageChange={(event) => setRowsPerPage(parseInt(event.target.value, 10))}
                sx={{
                    color: 'var(--color-black-5)',
                    '.MuiTablePagination-selectLabel': { color: 'var(--color-black-5)' },
                    '.MuiTablePagination-displayedRows': { color: 'var(--color-black-5)' },
                }}
            />
        </TableContainer>
    )
}

export default DataTable