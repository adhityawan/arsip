import { Alert, Snackbar } from "@mui/material";
import CheckIcon from '@mui/icons-material/Check';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';

const Alerts = ({ children, status = 'success' }) => {

    return (<Snackbar open={children} anchorOrigin={{ vertical: 'top', horizontal: 'right' }}>
        <Alert icon={status == 'success' ? <CheckIcon fontSize="inherit" /> : <CloseRoundedIcon fontSize="inherit" />} severity={status}>
            {children}
        </Alert>
    </Snackbar>);
}

export default Alerts;