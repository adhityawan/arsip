import { Box, Menu } from "@mui/material"
import { useState } from "react";

const Dropdown = ({ children, trigger }) => {
    const [open, setOpen] = useState(null);

    return (
        <>
            <Box onClick={(e) => setOpen(e.currentTarget)} className="text-end">{trigger}</Box>
            <Menu
                anchorEl={open}
                open={Boolean(open)}
                onClose={() => setOpen(null)}
                onClick={() => setOpen(null)}
                aria-haspopup="true"
                slotProps={{
                    paper: {
                        elevation: 0,
                        sx: {
                            overflow: 'visible',
                            filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.12))',
                            py: 0.2,
                            px: 1,
                            mt: 1,
                            '&::before': {
                                content: '""',
                                display: 'block',
                                position: 'absolute',
                                top: 0,
                                right: 14,
                                width: 10,
                                height: 10,
                                bgcolor: 'background.paper',
                                transform: 'translateY(-50%) rotate(45deg)',
                                zIndex: 0,
                            },
                        },
                    },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
                {children}
            </Menu>
        </>
    );
}

export default Dropdown;