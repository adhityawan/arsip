import { SECRET_KEY } from './config'
import CryptoJS from 'crypto-js';

export const encrypt = (payload) => {
    try {
        const encrypted = CryptoJS.AES.encrypt(JSON.stringify(payload), SECRET_KEY.slice(0, 32), {
            iv: SECRET_KEY.slice(0, 16),
            mode: CryptoJS.mode.CTRGladman,
            padding: CryptoJS.pad.Pkcs7
        });

        return encrypted.toString()
    } catch {
        return ''
    }
}

export const decrypt = (payload) => {
    try {
        const decrypted = CryptoJS.AES.decrypt(payload, SECRET_KEY.slice(0, 32), {
            iv: SECRET_KEY.slice(0, 16),
            mode: CryptoJS.mode.CTRGladman,
            padding: CryptoJS.pad.Pkcs7
        });

        return CryptoJS.enc.Utf8.stringify(decrypted)
    } catch {
        return ''
    }
}