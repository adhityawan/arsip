import { decrypt, encrypt } from "./encryp"
import { jwtDecode } from "jwt-decode"

export function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms))
}

export function converInputDate(date) {
    const d = new Date(date)
    const day = `0${d.getDate()}`.slice(-2)
    const month = `0${d.getMonth() + 1}`.slice(-2)
    const year = d.getFullYear()
    return `${year}-${month}-${day}`
}

export function randomString(length) {
    let result = ''
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length))
    }
    return result
}

export function addTokenResetPassword(token) {
    localStorage.setItem('forget', encrypt(token))
}

export function getTokenResetPassword() {
    const token = decrypt(localStorage.getItem('forget'))
    return token.slice(1, -1)
}

export function removeTokenResetPassword() {
    localStorage.removeItem('forget')
}

export function setToken(token) {
    const { avatar } = jwtDecode(token);
    avatar && sessionStorage.setItem('avatar', avatar)
    sessionStorage.setItem('token', encrypt(token))
}
export function deleteToken() {
    sessionStorage.clear()
    localStorage.clear()
}

export function getToken(key) {
    const token = sessionStorage.getItem('token')
    if (!token) { return null }
    try {
        const originalToken = jwtDecode(decrypt(token))
        if (key) { return JSON.parse(originalToken)[key] }
        return originalToken
    } catch {
        return null
    }
}

export function setHeaders(formData = false) {
    const token = sessionStorage.getItem('token')
    if (!token) { return null }

    try {
        return formData ? {
            headers: {
                'Content-Type': 'multipart/form-data',
                'Accept': 'application/json',
                'Authorization': `Bearer ${decrypt(token).slice(1, -1)}`
            }
        } : {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': `Bearer ${decrypt(token).slice(1, -1)}`
            }
        }
    } catch {
        return null
    }
}