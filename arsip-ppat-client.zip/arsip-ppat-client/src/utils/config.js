export const ENV = import.meta.env.VITE_ENVIRONMENT
export const BASE_URL = import.meta.env.VITE_BASE_URL
export const API_URL = import.meta.env.VITE_API_URL
export const SECRET_KEY = import.meta.env.VITE_SECRET_KEY
export const STATIC_ASSETS = import.meta.env.VITE_STATIC_ASSETS
export const DELEY_TIME = 5000
export const TIME_OUT = 30000