import { Outlet } from "react-router";
import Unauthorized from "../pages/error/unauthorized";
import { getToken } from "../utils/functions";


const ProtectedRoute = () => {
    const token = getToken();
    return token ? <Outlet /> : <Unauthorized />
}
 
export default ProtectedRoute;