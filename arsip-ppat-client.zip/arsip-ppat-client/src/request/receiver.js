import { get, post, put, remove, uploadPut } from "."
import { setHeaders } from "../utils/functions"

export const getRecipient = async () => {
    const { headers } = setHeaders()
    return await get({ url: `/recipient`, config: { headers } })
}

export const addRecipient = async (data) => {
    const { headers } = setHeaders()
    return await post({ url: `/recipient`, data, config: { headers } })
}

export const updateRecipient = async (data) => {
    const { headers } = setHeaders()
    const { id } = data
    delete data.id
    return await put({ url: `/recipient`, target: id, data, config: { headers } })
}

export const uploadAvatarRecipient = async (data) => {
    const { headers } = setHeaders(true)
    const { id } = data
    delete data.id
    return await uploadPut({ url: `/recipient/picture`, target: id, data, config: { headers } })
}

export const deleteRecipient = async (id) => {
    const { headers } = setHeaders()
    return await remove({ url: `/recipient`, target: id, config: { headers } })
}