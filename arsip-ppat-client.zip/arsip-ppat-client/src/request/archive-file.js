import { get, outRequest, remove, uploadPost, uploadPut } from "."
import { setHeaders } from "../utils/functions"

export const getArchiveFile = async (data) => {
    const { headers } = setHeaders()
    return await get({ url: `/storage`, data, config: { headers } })
}

export const addArchiveFile = async (data) => {
    const { headers } = setHeaders(true)
    return await uploadPost({ url: `/storage`, data, config: { headers } })
}

export const updateArchiveFile = async (data) => {
    const { headers } = setHeaders()
    const { id } = data
    delete data.id
    return await uploadPut({ url: `/storage`, target: id, data, config: { headers } })
}

export const deleteArchiveFile = async (id) => {
    const { headers } = setHeaders()
    return await remove({ url: `/storage`, target: id, config: { headers } })
}

export const downloadFile = async (url) => {
    return await outRequest({ method: 'get', url, config: { responseType: 'blob' } })
}