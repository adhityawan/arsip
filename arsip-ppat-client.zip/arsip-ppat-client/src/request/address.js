import { get } from "."
import { setHeaders } from "../utils/functions"

export const getProvince = async () => {
    const { headers } = setHeaders()
    const response = await get({ url: '/address/provinces', config: { headers } })
    return response.data
}

export const getCity = async (id) => {
    const { headers } = setHeaders()
    const response = await get({ url: `/address/regencies/${id}`, config: { headers } })
    return response.data
}

export const getSubdistrict = async (id) => {
    const { headers } = setHeaders()
    const response = await get({ url: `/address/districts/${id}`, config: { headers } })
    return response.data
}

export const getWard = async (id) => {
    const { headers } = setHeaders()
    const response = await get({ url: `/address/villages/${id}`, config: { headers } })
    return response.data
}