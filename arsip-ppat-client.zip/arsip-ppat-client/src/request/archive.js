import { get, post, put, remove } from "."
import { setHeaders } from "../utils/functions"

export const getArchive = async () => {
    const { headers } = setHeaders()
    return await get({ url: `/archive`, config: { headers } })
}

export const addArchive = async (data) => {
    const { headers } = setHeaders()
    return await post({ url: `/archive`, data, config: { headers } })
}

export const updateArchive = async (data) => {
    const { headers } = setHeaders()
    const { id } = data
    delete data.id
    return await put({ url: `/archive`, target: id, data, config: { headers } })
}

export const deleteArchive = async (id) => {
    const { headers } = setHeaders()
    return await remove({ url: `/archive`, target: id, config: { headers } })
}