import { get, post, put, remove, uploadPut } from "."
import { setHeaders } from "../utils/functions"

export const getUser = async () => {
    const { headers } = setHeaders()
    return await get({ url: `/user`, config: { headers } })
}

export const addUser = async (data) => {
    const { headers } = setHeaders()
    return await post({ url: `/user`, data, config: { headers } })
}

export const updateUser = async (data) => {
    const { headers } = setHeaders()
    const { id } = data
    delete data.id
    return await put({ url: `/user`, target: id, data, config: { headers } })
}

export const uploadAvatarUser = async (data) => {
    const { headers } = setHeaders(true)
    const { id } = data
    delete data.id
    return await uploadPut({ url: `/user/picture`, target: id, data, config: { headers } })
}

export const deleteUser = async (id) => {
    const { headers } = setHeaders()
    return await remove({ url: `/user`, target: id, config: { headers } })
}