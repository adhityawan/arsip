import { get, post, put, remove } from "."
import { setHeaders } from "../utils/functions"

export const getCategory = async () => {
    const { headers } = setHeaders()
    return await get({ url: `/category`, config: { headers } })
}

export const addCategory = async (data) => {
    const { headers } = setHeaders()
    return await post({ url: `/category`, data, config: { headers } })
}

export const updateCategory = async (data) => {
    const { headers } = setHeaders()
    const { id } = data
    delete data.id
    return await put({ url: `/category`, target: id, data, config: { headers } })
}

export const deleteCategory = async (id) => {
    const { headers } = setHeaders()
    return await remove({ url: `/category`, target: id, config: { headers } })
}