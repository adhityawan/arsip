import axios from 'axios'
import { API_URL, ENV, TIME_OUT } from '../utils/config'
import { encrypt, decrypt } from '../utils/encryp'

const request = axios.create({
    baseURL: API_URL,
    timeout: TIME_OUT
})

export const post = async ({ url, data, config }) => {
    try {
        const response = await request.post(url, { data: encrypt(data) }, config)

        if (response.status >= 200 && response.status < 300) {
            response.data.data = response.data.data ? JSON.parse(decrypt(response.data.data)) : ''
            return response.data
        } else {
            throw new Error(`Terjadi kesalahan tidak terduga:`)
        }
    } catch (err) {
        return {
            success: false,
            message: err.response?.data?.message || err.message || 'An error occurred',
        }
    }
}

export const get = async ({ url, data, config }) => {
    try {
        const key = data ? Object.keys(data) : undefined

        if (key) {
            key.forEach(key => {
                data[key] = encodeURIComponent(encrypt(data[key]))
            })
            url += `/${Object.values(data).join('/')}`
        }

        const response = await request.get(url, config)

        if (response.status >= 200 && response.status < 300) {
            response.data.data = JSON.parse(decrypt(response.data.data))
            return response.data
        } else {
            throw new Error(`Terjadi kesalahan tidak terduga:`)
        }
    } catch (err) {
        return {
            success: false,
            message: err.response?.data?.message || err.message || 'An error occurred',
        }
    }
}

export const put = async ({ url, target, data, config }) => {
    try {
        const response = await request.put(url + `/${encodeURIComponent(encrypt(target))}`, { data: encrypt(data) }, config)
        if (response.status >= 200 && response.status < 300) {
            return response.data
        } else {
            throw new Error(`Terjadi kesalahan tidak terduga:`)
        }
    } catch (err) {
        return {
            success: false,
            message: err.response?.data?.message || err.message || 'An error occurred',
        }
    }
}

export const remove = async ({ url, target, config }) => {
    try {
        const response = await request.delete(url + `/${encodeURIComponent(encrypt(target))}`, config)
        if (response.status >= 200 && response.status < 300) {
            return response.data
        } else {
            throw new Error(`Terjadi kesalahan tidak terduga:`)
        }
    } catch (err) {
        return {
            success: false,
            message: err.response?.data?.message || err.message || 'An error occurred',
        }
    }
}

export const uploadPost = async ({ url, data, config }) => {
    try {
        const response = await request.post(url, data, config)
        if (response.status >= 200 && response.status < 300) {
            return response.data
        } else {
            throw new Error(`Terjadi kesalahan tidak terduga:`)
        }
    } catch (err) {
        return {
            success: false,
            message: err.response?.data?.message || err.message || 'An error occurred',
        }
    }
}

export const uploadPut = async ({ url, target, data, config }) => {
    const formData = new FormData();
    Object.keys(data).forEach(key => formData.append(key, data[key]));

    try {
        const response = await request.put(`${url}/${encodeURIComponent(encrypt(target))}`, formData, config);

        if (response.status >= 200 && response.status < 300) {
            return response.data;
        }

        throw new Error(`Terjadi kesalahan tidak terduga:`);
    } catch (err) {
        return {
            success: false,
            message: err.response?.data?.message || err.message || 'An error occurred',
        };
    }
}

export const outRequest = ({ method, url, data, config }) => {
    url = ENV == 'production' && url.startsWith('http://') ? url.replace('http://', 'https://') : url

    const methods = {
        post: async () => {
            const response = await axios.post(url, data, config)
            return response.data
        },
        get: async () => {
            try {
                const response = await axios.get(url, { params: data, ...config })
                return response.data
            } catch (err) {
                return {
                    success: false,
                    message: err.response?.data?.message || err.message || 'An error occurred',
                }
            }
        },
        put: async () => {
            const response = await axios.put(url, data, config)
            return response.data
        },
        delete: async () => {
            const response = await axios.delete(url, config)
            return response.data
        },
    }

    if (methods[method]) {
        return methods[method]()
    } else {
        throw new Error(`Unsupported method: ${method}`)
    }
}