import { post } from "."

export const login = async (data) => {
    return await post({ url: `/authentication`, data})
}

export const forget = async (data) => {
    return await post({ url: `/authentication/forget`, data})
}

export const confirm = async (data) => {
    return await post({ url: `/authentication/confirm`, data})
}

export const reset = async (data) => {
    return await post({ url: `/authentication/reset`, data})
}