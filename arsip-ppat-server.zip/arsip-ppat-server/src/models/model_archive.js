const sequelize = require('sequelize');
const db = require('../config/conection');

const Archive = db.define('archives', {
    id: {
        type: sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    number: {
        type: sequelize.STRING,
        allowNull: false
    },
    id_recipient: {
        type: sequelize.INTEGER,
    },
    date: {
        type: sequelize.DATE,
        defaultValue: new Date().toISOString().split('T')[0]
    },
    regarding: {
        type: sequelize.STRING(100),
        allowNull: false
    },
    id_category: {
        type: sequelize.INTEGER,
        allowNull: false
    },
    address: {
        type: sequelize.TEXT,
    },
    accepted: {
        type: sequelize.DATE,
    },
    status: {
        type: sequelize.BOOLEAN,
        defaultValue: false
    }
}, {
    tableName: 'archives',
    timestamps: false,
    freezeTableName: true
});

module.exports = Archive