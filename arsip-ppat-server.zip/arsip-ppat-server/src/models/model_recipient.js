const sequelize = require('sequelize');
const db = require('../config/conection');

const Recipient = db.define('recipients', {
    id: {
        type: sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    name: {
        type: sequelize.STRING,
        allowNull: false
    },
    email: {
        type: sequelize.STRING,
        allowNull: false,
        unique: true
    },
    avatar: {
        type: sequelize.STRING
    },
    phone: {
        type: sequelize.STRING(20)
    },
    province: {
        type: sequelize.STRING(100)
    },
    city: {
        type: sequelize.STRING(100)
    },
    subdistrict: {
        type: sequelize.STRING(100)
    },
    ward: {
        type: sequelize.STRING(100)
    }
}, {
    tableName: 'recipients',
    timestamps: false,
    freezeTableName: true
});

module.exports = Recipient