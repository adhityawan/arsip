const User = require('./model_users')
const Recipient = require('./model_recipient')
const ArchiveFiles = require('./model_file')
const Archive = require('./model_archive')
const Category = require('./model_category')

Archive.belongsTo(Recipient, { foreignKey: 'id_recipient' });
Recipient.hasOne(Archive, { foreignKey: 'id_recipient' });
Archive.belongsTo(Category, { foreignKey: 'id_category' });
Category.hasOne(Archive, { foreignKey: 'id_category' });

const Model = {}
Model.user = User
Model.recipient = Recipient
Model.archive = Archive
Model.archiveFiles = ArchiveFiles
Model.category = Category

module.exports = Model