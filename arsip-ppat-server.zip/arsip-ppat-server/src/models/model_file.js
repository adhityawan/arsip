const sequelize = require('sequelize')
const db = require('../config/conection')

const ArchiveFiles = db.define('archive_files', {
    id: {
        type: sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    id_archive: {
        type: sequelize.INTEGER,
        allowNull: false
    },
    filename: {
        type: sequelize.STRING,
        allowNull: false
    },
    owner: {
        type: sequelize.STRING
    }
}, {
    tableName: 'archive_files',
    timestamps: false,
    freezeTableName: true
})

module.exports = ArchiveFiles