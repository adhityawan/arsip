const sequelize = require('sequelize');
const db = require('../config/conection');

const Category = db.define('categorys', {
    id: {
        type: sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    category: {
        type: sequelize.STRING(100),
        allowNull: false
    },
    description: {
        type: sequelize.TEXT
    }
}, {
    tableName: 'categorys',
    timestamps: false,
    freezeTableName: true
});

module.exports = Category