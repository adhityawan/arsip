const sequelize = require('sequelize');
const db = require('../config/conection');

const User = db.define('users', {
    id: {
        type: sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    name: {
        type: sequelize.STRING,
        allowNull: false
    },
    email: {
        type: sequelize.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: sequelize.STRING,
        allowNull: false
    },
    avatar: {
        type: sequelize.STRING
    },
    phone: {
        type: sequelize.STRING(20)
    },
    province: {
        type: sequelize.STRING(100)
    },
    city: {
        type: sequelize.STRING(100)
    },
    subdistrict: {
        type: sequelize.STRING(100)
    },
    ward: {
        type: sequelize.STRING(100)
    },
    otp: {
        type: sequelize.STRING(100)
    },
    exp: {
        type: sequelize.DATE
    },
    status: {
        type: sequelize.BOOLEAN,
        defaultValue: true
    }
}, {
    tableName: 'users',
    timestamps: false,
    freezeTableName: true
});

module.exports = User