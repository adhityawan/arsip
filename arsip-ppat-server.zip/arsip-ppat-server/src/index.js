const app = require('./app');
const {PORT_APP } = process.env
const port = PORT_APP || 5000;
app.listen(port, () => {
    console.log(`Listening: http://localhost:${port}`);
});
