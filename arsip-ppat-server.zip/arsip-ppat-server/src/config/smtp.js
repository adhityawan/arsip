const { SMTP_USER, SMTP_PASS, SMTP_HOST, SMTP_POST } = process.env
const nodemailer = require("nodemailer");

exports.transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_POST,
    secure: false,
    auth: {
        user: SMTP_USER,
        pass: SMTP_PASS,
    },
});