const jwt = require('jsonwebtoken')
const Model = require('../models')
const { SECRET_KEY } = process.env

module.exports = {
    protected: async (req, res, next) => {
        const token = req.header('Authorization')

        if (!token) {
            return res.status(401).json({
                status: 'failed',
                message: 'Anda harus login terlebih dahulu'
            })
        }

        try {
            const decodedPayload = jwt.verify(token.replace('Bearer ', ''), SECRET_KEY)
            const user = await Model.user.findOne({ where: { id: decodedPayload.id, status: 1 } })
            req.user = user
            return user ? next() : res.status(401).json({
                status: 'failed',
                message: 'Access denied'
            })
        } catch (error) {
            res.status(400).json({
                status: 'failed',
                message: 'Token tidak valid'
            })
        }
    }
}