const multer = require('multer')
const fs = require('fs')
const path = require('path')


module.exports = {
    upload: (filepath, size = 100) => {
        const storage = multer.diskStorage({
            destination: (req, file, callback) => {
                const dir = `src/assets/${filepath}`
                fs.mkdirSync(dir, { recursive: true })
                callback(null, dir)
            },
            filename: (req, file, callback) => {
                callback(null, `${filepath}-${Date.now() + path.extname(file.originalname)}`.toLowerCase())
            }
        })

        return multer({
            storage,
            limits: {
                fileSize: size * 1024 * 1024
            }
        })
    }
}