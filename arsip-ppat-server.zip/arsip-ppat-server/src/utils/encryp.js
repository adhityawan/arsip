const CryptoJS = require('crypto-js');
const bcrypt = require('bcryptjs')
const { ENCRYP_LENGTH, ENCRYP_KEY } = process.env

module.exports = {
    password_hash: (string) => {
        const salt = bcrypt.genSaltSync(parseInt(ENCRYP_LENGTH))
        const hash = bcrypt.hashSync(string, salt)
        return hash
    },

    password_verify: (string, hash) => {
        return bcrypt.compareSync(string, hash)
    },

    payload_encrypt: (payload) => {
        try {
            const encrypted = CryptoJS.AES.encrypt(JSON.stringify(payload), ENCRYP_KEY.slice(0, 32), {
                iv: ENCRYP_KEY.slice(0, 16),
                mode: CryptoJS.mode.CTRGladman,
                padding: CryptoJS.pad.Pkcs7
            });

            return encrypted.toString()
        } catch {
            return ''
        }
    },

    payload_decrypt: (payload) => {
        try {
            const decrypted = CryptoJS.AES.decrypt(payload, ENCRYP_KEY.slice(0, 32), {
                iv: ENCRYP_KEY.slice(0, 16),
                mode: CryptoJS.mode.CTRGladman,
                padding: CryptoJS.pad.Pkcs7
            });

            return JSON.parse(decrypted.toString(CryptoJS.enc.Utf8))
        } catch {
            return ''
        }
    }
}