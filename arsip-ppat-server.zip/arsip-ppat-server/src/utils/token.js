const jwt = require('jsonwebtoken');
const { SECRET_KEY } = process.env

module.exports = {
    generateToken: ({ payload, exp = 604800, liveTime = false }) => {
        const data = { ...payload }
        return liveTime ? jwt.sign(data, SECRET_KEY) : jwt.sign(data, SECRET_KEY, { expiresIn: exp });
    },

    verifyToken: (token) => {
        try {
            return jwt.verify(token, SECRET_KEY);
        } catch (error) {
            return false
        }
    }
}