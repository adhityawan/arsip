const fs = require('fs')

module.exports = {
    randomNumber: (length) => {
        const chart = '0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chart.charAt(Math.floor(Math.random() * chart.length));
        }

        return result
    },

    readFileAsync: async (filePath, encoding) => {
        return new Promise((resolve, reject) => {
            fs.readFile(filePath, encoding, (err, data) => {
                if (err) reject(err)
                else resolve(data)
            })
        })
    },

    deleteFileAsync: async (filePath) => {
        return fs.promises.unlink(filePath).catch((err) => {
            if (err.code !== 'ENOENT') throw err
        })
    }
}