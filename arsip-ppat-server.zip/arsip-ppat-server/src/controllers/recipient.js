const express = require('express')
const Model = require('../models')
const { upload } = require('../middleweres/upload')
const router = express.Router()
const path = require("path")
const { payload_encrypt, payload_decrypt } = require('../utils/encryp')
const { deleteFileAsync } = require('../utils/functions')
const { log } = require('console')

router.get('/', async (req, res) => {
    try {
        const data = await Model.recipient.findAll()

        if (data) {
            const newData = [
                ...data.map((item) => {
                    return {
                        id: item.id,
                        name: item.name,
                        email: item.email,
                        avatar: item.avatar ? `${req.protocol}://${req.headers.host}/assets/avatar/${item.avatar}` : '',
                        phone: item.phone,
                        province: item.province,
                        city: item.city,
                        subdistrict: item.subdistrict,
                        ward: item.ward,
                    }
                })
            ]
            req.response.status = 'success'
            req.response.message = 'Penerima ditemukan'
            req.response.data = payload_encrypt(newData)
        } else {
            req.response.status = 'failed'
            req.response.message = 'Penerima tidak ditemukan'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/', async (req, res) => {
    const { name, email, phone, province, city, subdistrict, ward } = payload_decrypt(req.body.data)

    if (name.trim() != '' && email.trim() != '') try {
        const data = await Model.recipient.create({ name, email, phone, province, city, subdistrict, ward })

        if (data) {
            req.response.status = 'success'
            req.response.message = 'Penerima berhasil dibuat'
        }
    } catch (error) {
        if (error.name == 'SequelizeUniqueConstraintError') {
            req.response.status = 'failed'
            req.response.message = 'Email sudah terdaftar'
        } else {
            console.warn(error)
        }
    }

    res.status(200).json(req.response)
})

router.put('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))
    const { name, email, phone, province, city, subdistrict, ward } = payload_decrypt(req.body.data)

    try {
        const data = await Model.recipient.update({ name, email, phone, province, city, subdistrict, ward }, { where: { id } })

        if (data[0]) {
            req.response.status = 'success'
            req.response.message = 'Penerima berhasil diubah'
        } else {
            req.response.status = 'success'
            req.response.message = 'Penerima gagal diubah'
        }
    } catch (error) {
        if (error.name == 'SequelizeUniqueConstraintError') {
            req.response.status = 'failed'
            req.response.message = 'Email sudah terdaftar'
        } else {
            console.warn(error)
        }
    }

    res.status(200).json(req.response)
})

router.put('/picture/:id', upload('avatar', 12).single('avatar'), async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))

    try {
        if (!req.file) {
            req.response.status = 'failed';
            req.response.message = 'Foto penerima gagal diubah';
            return;
        }

        const { avatar } = await Model.recipient.findOne({ where: { id } });
        const data = await Model.recipient.update({ avatar: req.file.filename }, { where: { id } });

        if (data[0]) {
            avatar && await deleteFileAsync(path.join(__dirname, `../assets/avatar/${avatar}`));
            req.response.status = 'success';
            req.response.message = 'Foto penerima berhasil diubah';
        } else {
            await deleteFileAsync(path.join(__dirname, `../assets/avatar/${req.file.filename}`));
            req.response.status = 'failed';
            req.response.message = 'Foto penerima gagal diubah';
        }
    } catch (error) {
        console.warn(error);
    }

    res.status(200).json(req.response)
})

router.delete('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))

    try {
        const { avatar } = await Model.recipient.findOne({ where: { id } });
        const data = await Model.recipient.destroy({ where: { id } })

        if (data) {
            await deleteFileAsync(path.join(__dirname, `../assets/avatar/${avatar}`))
            req.response.status = 'success'
            req.response.message = 'Penerima berhasil dihapus'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

module.exports = router