const express = require('express')
const Model = require('../models')
const { upload } = require('../middleweres/upload')
const { verifyToken, generateToken } = require('../utils/token')
const router = express.Router()
const path = require("path")
const { deleteFileAsync } = require('../utils/functions')
const { payload_decrypt, payload_encrypt } = require('../utils/encryp')

router.get('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))

    try {
        const data = await Model.archiveFiles.findAll({ where: { id_archive: id } })

        if (data) {
            const newData = [
                ...data.map((item) => {
                    return {
                        id: item.id,
                        filename: item.filename,
                        file: item.filename ? `${req.protocol}://${req.headers.host}/assets/document/${item.filename}` : '',
                        owner: verifyToken(item.owner)[0].name
                    }
                })
            ]
            req.response.status = 'success'
            req.response.message = 'Arsip ditemukan'
            req.response.data = payload_encrypt(newData)
        } else {
            req.response.status = 'failed'
            req.response.message = 'Arsip tidak ditemukan'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/', upload('document', 100).single('file'), async (req, res) => {
    const { id_archive } = req.body

    try {
        if (req.file) {
            const data = await Model.archiveFiles.create({
                id_archive,
                owner: generateToken({
                    payload: [{
                        name: req.user.name,
                        email: req.user.name,
                        date: new Date()
                    }],
                    liveTime: true
                }),
                filename: req.file.filename
            })

            if (data) {
                req.response.status = 'success'
                req.response.message = 'File berhasil diarsipkan'
            }
        } else {
            req.response.status = 'failed'
            req.response.message = 'File gagal diarsipkan'
        }
    } catch (error) {
        if (error.name == 'SequelizeForeignKeyConstraintError') {
            req.response.status = 'failed'
            req.response.message = 'Arsip tidak ditemukan'
        }
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.put('/:id', upload('document', 100).single('file'), async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))

    try {
        if (req.file) {
            const file = await Model.archiveFiles.findOne({ attributes: ['filename', 'owner'] }, { where: { id } })

            const queryData = {
                owner: generateToken({
                    payload: [
                        ...Object.values(
                            verifyToken(file.owner)
                        ).slice(0, -1),
                        {
                            name: req.user.name,
                            email: req.user.name,
                            date: new Date()
                        }
                    ],
                    liveTime: true
                }),
            }

            queryData.filename = req.file.filename
            const data = await Model.archiveFiles.update(queryData, { where: { id } })

            if (data) {
                await deleteFileAsync(path.join(__dirname, `../assets/document/${file.filename}`))
                req.response.status = 'success'
                req.response.message = 'File arsip berhasil diubah'
            } else {
                req.response.status = 'failed'
                req.response.message = 'File arsip gagal diubah'
            }
        } else {
            req.response.status = 'failed'
            req.response.message = 'Permintaan tidak sah'
        }
    } catch (error) {
        if (error.name == 'SequelizeForeignKeyConstraintError') {
            req.response.status = 'failed'
            req.response.message = 'Arsip tidak ditemukan'
        }
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.delete('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))
    
    try {
        const { filename } = await Model.archiveFiles.findOne({ where: { id } });
        const data = await Model.archiveFiles.destroy({ where: { id } })

        if (data) {
            await deleteFileAsync(path.join(__dirname, `../assets/document/${filename}`))
            req.response.status = 'success'
            req.response.message = 'Pengguna berhasil dihapus'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

module.exports = router