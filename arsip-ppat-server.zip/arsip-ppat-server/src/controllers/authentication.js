const { generateToken, verifyToken } = require('../utils/token')
const { readFileAsync, randomNumber } = require('../utils/functions')
const { password_verify, password_hash, payload_decrypt, payload_encrypt } = require('../utils/encryp')
const { transporter } = require('../config/smtp')
const { EXP_OTP, SMTP_USER } = process.env
const express = require('express')
const Model = require('../models')
const router = express.Router()
const path = require('path')

router.post('/', async (req, res) => {
    const { email, password } = payload_decrypt(req.body.data)

    if (email.trim() != '' && password.trim() != '') try {
        const user = await Model.user.findOne({ where: { email, status: 1 } })

        if (user) {
            const verify = password_verify(password, user.password)

            if (verify) {
                req.response.status = 'success'
                req.response.message = 'Login Berhasil'
                req.response.data = payload_encrypt({
                    token: generateToken({
                        payload: {
                            id: user.id,
                            name: user.name,
                            email: user.email,
                            avatar: user.avatar ? `${req.protocol}://${req.headers.host}/assets/avatar/${user.avatar}` : ''
                        }
                    })
                })
            } else {
                req.response.status = 'failed'
                req.response.message = 'Email atau sandi salah'
            }
        } else {
            req.response.status = 'failed'
            req.response.message = 'Email atau sandi salah'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/forget', async (req, res) => {

    const { email } = payload_decrypt(req.body.data)

    if (email.trim() != '') try {
        const user = await Model.user.findOne({ where: { email, status: 1 } })
        const reset_password = await readFileAsync(path.join(__dirname, '../mailtemplates/reset_password.html'), 'utf8')
        const otp = randomNumber(6)

        if (user) {
            const status = await transporter.sendMail({
                from: SMTP_USER,
                to: email,
                subject: `Reset Password`,
                text: `Test Email`,
                html: reset_password
                    .replace('{{nama_pengguna}}', user.name)
                    .replace('{{otp_code}}', otp)
            })

            status.response.includes('OK') && await Model.user.update({ otp, exp: new Date() }, { where: { email, status: 1 } })
            req.response.status = 'success'
            req.response.message = 'OTP telah dikirim ke alamat email Anda'

        } else {
            req.response.status = 'failed'
            req.response.message = 'Alamat email tidak terdaftar'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/confirm', async (req, res) => {

    const { otp } = payload_decrypt(req.body.data)

    if (otp.trim() != '') try {
        const user = await Model.user.findOne({ where: { otp, status: 1 } })

        if (user && new Date(user.exp).getTime() + (EXP_OTP * 60 * 1000) > new Date().getTime()) {
            const data = await Model.user.update({ exp: new Date(new Date(user.exp).getTime() - (EXP_OTP * 60 * 1000)) }, { where: { otp } })

            if (data[0]) {
                req.response.status = 'success'
                req.response.message = 'Kode OTP terkonfirmasi'
                req.response.data = payload_encrypt({
                    token: generateToken({
                        payload: {
                            id: user.id,
                            email: user.email
                        },
                        exp: 300
                    })
                })
            } else {
                req.response.status = 'failed'
                req.response.message = 'Kode OTP tidak valid'
            }
        } else {
            req.response.status = 'failed'
            req.response.message = 'Kode OTP tidak valid'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/reset', async (req, res) => {

    const { password, token } = payload_decrypt(req.body.data)

    if (token.trim() != '') try {
        const verify = verifyToken(token)

        if (verify) {
            const data = await Model.user.update({ password: password_hash(password) }, { where: { id: verify.id } })

            if (data[0]) {
                req.response.status = 'success'
                req.response.message = 'Sandi berhasil diubah'
            } else {
                req.response.status = 'failed'
                req.response.message = 'Sandi tidak berhasil diubah'
            }
        } else {
            req.response.status = 'failed'
            req.response.message = 'Permintaan tidak sah'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

module.exports = router