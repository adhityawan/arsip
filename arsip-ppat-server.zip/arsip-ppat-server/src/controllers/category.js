const express = require('express')
const { payload_decrypt, payload_encrypt } = require('../utils/encryp')
const Model = require('../models')
const router = express.Router()

router.get('/', async (req, res) => {
    try {
        const data = await Model.category.findAll()

        if (data) {
            req.response.status = 'success'
            req.response.message = 'Kategori ditemukan'
            req.response.data = payload_encrypt(data)
        } else {
            req.response.status = 'failed'
            req.response.message = 'Kategori tidak ditemukan'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/', async (req, res) => {
    const { category, description } = payload_decrypt(req.body.data)

    if (category.trim() != '') try {
        const data = await Model.category.create({ category, description })

        if (data) {
            req.response.status = 'success'
            req.response.message = 'Kategori berhasil dibuat'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.put('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))
    
    const { category, description } = payload_decrypt(req.body.data)

    try {
        const data = await Model.category.update({ category, description }, { where: { id } })

        if (data[0]) {
            req.response.status = 'success'
            req.response.message = 'Kategori berhasil diubah'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.delete('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))

    try {
        const data = await Model.category.destroy({ where: { id } })

        if (data) {
            req.response.status = 'success'
            req.response.message = 'Kategori berhasil dihapus'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

module.exports = router