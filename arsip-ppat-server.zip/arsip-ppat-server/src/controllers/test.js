const express = require('express')
const { payload_encrypt, payload_decrypt } = require('../utils/encryp')
const router = express.Router()

router.post('/encrypt', async (req, res) => {
    req.response.status = 'success'
    req.response.message = 'Email sudah terdaftar'
    req.response.data = payload_encrypt(req.body)

    res.status(200).json(req.response)
})

router.post('/dencrypt', async (req, res) => {
    req.response.status = 'success'
    req.response.message = 'Email sudah terdaftar'
    const decrypt = payload_decrypt(req.body.data)
    req.response.data = decrypt.length == 0 ? 'enkripsi tidak valid' : decrypt

    res.status(200).json(req.response)
})

router.get('/prov', async (req, res) => {
    try {
        const response = await fetch("https://wilayah.id/api/provinces.json", {
            method: "get",
        })
        const data = await response.json()
        res.status(200).json(data)
    } catch (error) {
        console.error("Error fetching provinces:", error)
    }
})

module.exports = router