const express = require('express')
const Model = require('../models')
const { upload } = require('../middleweres/upload')
const { payload_decrypt, payload_encrypt } = require('../utils/encryp')
const router = express.Router()

router.get('/', async (req, res) => {
    try {
        const data = await Model.archive.findAll({ include: [{ model: Model.recipient }, { model: Model.category }] })

        if (data) {
            const newData = [
                ...data.map(item => {
                    return {
                        id: item.id,
                        number: item.number,
                        recipient: item.recipient.name,
                        date: item.date,
                        regarding: item.regarding,
                        category: item.category.category,
                        address: item.address,
                        accepted: item.accepted,
                        status: item.status,
                        id_category: item.id_category,
                        id_recipient: item.id_recipient
                    }
                })
            ]
            req.response.status = 'success'
            req.response.message = 'Arsip ditemukan'
            req.response.data = payload_encrypt(newData)
        } else {
            req.response.status = 'failed'
            req.response.message = 'Arsip tidak ditemukan'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.post('/', async (req, res) => {
    const { number, id_recipient, date, regarding, id_category, address, accepted, status } = payload_decrypt(req.body.data)
    if (number.trim() != '' && regarding.trim() != '' && id_category) try {
        const data = await Model.archive.create({ number, id_recipient, date, regarding, id_category, address, accepted, status })
        
        if (data) {
            req.response.status = 'success'
            req.response.message = 'Arsip berhasil dibuat'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.put('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))
    const { number, id_recipient, date, regarding, id_category, address, accepted, status } = payload_decrypt(req.body.data)
    
    try {
        const data = await Model.archive.update({ number, id_recipient, date, regarding, id_category, address, accepted, status }, { where: { id } })

        if (data[0]) {
            req.response.status = 'success'
            req.response.message = 'Arsip berhasil diubah'
        } else {
            req.response.status = 'failed'
            req.response.message = 'Tidak ada perubahan'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

router.delete('/:id', async (req, res) => {
    const id = payload_decrypt(decodeURIComponent(req.params.id))

    try {
        const data = await Model.archive.destroy({ where: { id } })

        if (data) {
            req.response.status = 'success'
            req.response.message = 'Arsip berhasil dihapus'
        }
    } catch (error) {
        console.warn(error)
    }

    res.status(200).json(req.response)
})

module.exports = router