const { protected } = require('../middleweres/authentication')
const express = require('express')
const router = express.Router()

// Authentication
const authentication = require('./authentication')
const category = require('./category')
const recipient = require('./recipient')
const user = require('./user')
const archive = require('./archive')
const storage = require('./storage')
const address = require('./address')
const test = require('./test')

router.use('/authentication', authentication)
router.use('/address', protected, address)
router.use('/category', protected, category)
router.use('/recipient', protected, recipient)
router.use('/user', protected, user)
router.use('/archive', protected, archive)
router.use('/storage', protected, storage)
router.use('/test', test)

module.exports = router