const express = require('express')
const { payload_encrypt } = require('../utils/encryp')
const router = express.Router()

router.get('/provinces', async (req, res) => {
    try {
        const response = await fetch("https://wilayah.id/api/provinces.json", {
            method: "get",
        })
        const data = await response.json()
        if (data) {
            req.response.status = 'success'
            req.response.message = 'Data provinsi berhasil diambil'
            req.response.data = payload_encrypt(data.data)
        }
    } catch (error) {
        console.error("Error fetching provinces:", error)
    }

    res.status(200).json(req.response)
})

router.get('/regencies/:id', async (req, res) => {
    try {
        const response = await fetch(`https://wilayah.id/api/regencies/${req.params.id}.json`, {
            method: "get",
        })
        const data = await response.json()
        if (data) {
            req.response.status = 'success'
            req.response.message = 'Data kecamatan berhasil diambil'
            req.response.message = 'regencies'
            req.response.data = payload_encrypt(data.data)
        }
    } catch (error) {
        console.error("Error fetching regencies:", error)
    }

    res.status(200).json(req.response)
})

router.get('/districts/:id', async (req, res) => {
    try {
        const response = await fetch(`https://wilayah.id/api/districts/${req.params.id}.json`, {
            method: "get",
        })
        const data = await response.json()
        if (data) {
            req.response.status = 'success'
            req.response.message = 'Data kecamatan berhasil diambil'
            req.response.data = payload_encrypt(data.data)
        }
    } catch (error) {
        console.error("Error fetching districts:", error)
    }

    res.status(200).json(req.response)
})

router.get('/villages/:id', async (req, res) => {
    try {
        const response = await fetch(`https://wilayah.id/api/villages/${req.params.id}.json`, {
            method: "get",
        })
        const data = await response.json()
        if (data) {
            req.response.status = 'success'
            req.response.message = 'Data desa berhasil diambil'
            req.response.data = payload_encrypt(data.data)
        }
    } catch (error) {
        console.error("Error fetching villages:", error)
    }

    res.status(200).json(req.response)
})

module.exports = router;