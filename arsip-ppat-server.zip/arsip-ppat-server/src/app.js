require('dotenv').config()
const express = require('express')
const cors = require('cors')
const morgan = require('morgan')
const bodyParser = require('body-parser')
const path = require("path")
const controllers = require('./controllers')
const app = express()
const { ORIGIN } = process.env

app.use(morgan('dev'))
app.use(cors({
    origin: ORIGIN,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}))

app.use(bodyParser.json({
    limit: '100mb',
    extended: true
}))
app.use(bodyParser.urlencoded({
    limit: '100mb',
    extended: true
}))
app.use("/assets/", express.static(path.join(__dirname, "assets/")))

app.all('*any', (req, res, next) => {
    console.clear()
    req.response = {
        status: 'failed',
        message: 'Permintaan tidak valid'
    }
    res.set('Content-Type', 'application/json');
    next()
})

app.get('/', (req, res) => {
    res.json({
        message: '🦄🌈✨👋🌎 - Service Arsip Surat - 🌏👋✨🌈🦄'
    })
})

app.use('/api', controllers)

app.use('*any', (req, res) => {
    req.response = {
        status: 'Not Found',
        message: 'Halaman tidak ditemukan',
    }

    res.status(404).json(req.response)
})

module.exports = app